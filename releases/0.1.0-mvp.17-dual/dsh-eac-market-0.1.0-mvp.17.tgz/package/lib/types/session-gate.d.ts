/** A handshake is bound to the official transport peer, never a client-supplied
 * identity. It is capability negotiation, not user consent or authentication.
 * Every UI write renegotiates, so expiry/reconnect cannot silently reuse a gate.
 */
export declare class ClientSessionGate {
    private readonly protocol;
    private readonly now;
    private readonly sessions;
    constructor(protocol: string, now?: () => number);
    connect(peerId: string, clientProtocol: string): boolean;
    assert(peerId: string): void;
}
//# sourceMappingURL=session-gate.d.ts.map