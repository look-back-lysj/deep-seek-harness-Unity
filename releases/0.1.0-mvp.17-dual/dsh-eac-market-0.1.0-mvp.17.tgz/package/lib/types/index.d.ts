import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { AiAnalyzeRequest, AiAnalysisResult, AiApplyResult, AiConfirmRequest, type ClientHandshakeRequest, type ClientHandshakeResult, type AuthorDraft, type AuthorDraftDeleteRequest, type AuthorDraftInput, type AuthorExportRequest, type AuthorMediaReadRequest, type AuthorMediaReadResult, type CatalogRefreshRequest, type CatalogRefreshView, type CatalogSnapshot, type CatalogSourceView, type CoreMaintenanceSnapshot, type UpdateCheckResult, type UpdatePolicySnapshot, type UpdatePolicySaveRequest, type DiagnosticExport, type EnvironmentHello, type InventorySnapshot, type PlanCreateRequest, type PlanResult, type PluginActionResult, type PluginActionRequest, type ReadmeImportRequest, type ReadmeImportResult, type ReadmePreviewView, type ReadmeApplyPreviewRequest, type RemovePluginRequest, type TaskApprovalRequest, type TaskCancelRequest, type TaskEventPage, type TaskEventRequest, type TaskIdRequest, type TaskResumeRequest, type TaskStartRequest, type TaskState, type TransferBeginRequest, type TransferChunkReadRequest, type TransferChunkReadResult, type TransferChunkRequest, type TransferDisposeRequest, type TransferResult } from './types.ts';
export interface Config {
    readonly dataDirectory?: string;
    /** Maintainer configuration, not writable by catalogRefresh or author content. */
    readonly catalogSources?: {
        readonly id: string;
        readonly indexUrl: string;
        readonly maintainer: string;
        readonly fallbackId?: string;
    }[];
    /** Host-maintained Agent Forge sources. Local paths are intentionally not accepted in plugin config. */
    readonly agentForgeSources?: {
        readonly id: string;
        readonly locationUrl: string;
        readonly expectedRevision: string;
        readonly enabled: boolean;
        readonly priority: number;
        readonly refreshPolicy: string;
    }[];
}
/** @typert service eacMarket */
export declare class MarketService extends Service {
    static inject: string[];
    static Config: z<Config>;
    private readonly context;
    private readonly profileDir;
    private readonly marketDataDir;
    private readonly hostVersion;
    readonly typertRemote: unknown;
    private readonly runtime;
    private readonly clientSessions;
    constructor(ctx: Context, config?: Config);
    private remoteCaller;
    private assertWriteCompatible;
    clientConnect(request: ClientHandshakeRequest): ClientHandshakeResult;
    hello(): EnvironmentHello;
    catalog(): CatalogSnapshot;
    catalogRefresh(request?: CatalogRefreshRequest): Promise<CatalogRefreshView>;
    catalogSources(): Promise<readonly CatalogSourceView[]>;
    agentForgeRefresh(request: {
        readonly sourceId: string;
    }): Promise<CatalogRefreshView>;
    maintenanceStatus(): Promise<CoreMaintenanceSnapshot>;
    checkUpdates(request?: {
        readonly sourceId?: string;
        readonly refreshFirst?: boolean;
    }): Promise<UpdateCheckResult>;
    updatePolicyGet(): Promise<UpdatePolicySnapshot>;
    updatePolicySave(request: UpdatePolicySaveRequest): Promise<UpdatePolicySnapshot>;
    inventory(): Promise<InventorySnapshot>;
    planCreate(request: PlanCreateRequest): Promise<PlanResult>;
    taskStart(request: TaskStartRequest): Promise<TaskState>;
    taskGet(request: TaskIdRequest): Promise<TaskState>;
    taskList(): Promise<readonly TaskState[]>;
    taskEvents(request: TaskEventRequest): Promise<TaskEventPage>;
    taskApproveBuilds(request: TaskApprovalRequest): Promise<TaskState>;
    taskResume(request: TaskResumeRequest): Promise<TaskState>;
    taskCancel(request: TaskCancelRequest): Promise<TaskState>;
    pluginSetEnabled(request: PluginActionRequest): Promise<PluginActionResult>;
    pluginRemove(request: RemovePluginRequest): Promise<PluginActionResult>;
    authorDraftList(): readonly AuthorDraft[];
    authorDraftGet(id: string): AuthorDraft;
    authorDraftSave(input: AuthorDraftInput): AuthorDraft;
    authorDraftDelete(request: AuthorDraftDeleteRequest): boolean;
    authorReadmeImport(request: ReadmeImportRequest): Promise<ReadmeImportResult>;
    authorReadmePreview(request: ReadmeImportRequest): Promise<ReadmePreviewView>;
    authorReadmeApplyPreview(request: ReadmeApplyPreviewRequest): ReadmeImportResult;
    authorTransferBegin(request: TransferBeginRequest): TransferResult;
    authorTransferChunk(request: TransferChunkRequest): Promise<TransferResult>;
    authorTransferRead(request: TransferChunkReadRequest): TransferChunkReadResult;
    authorTransferDispose(request: TransferDisposeRequest): boolean;
    authorExportDraft(request: AuthorExportRequest): TransferResult;
    authorMediaRead(request: AuthorMediaReadRequest): AuthorMediaReadResult;
    diagnosticsExport(): Promise<DiagnosticExport>;
    aiAnalyze(request: AiAnalyzeRequest): Promise<AiAnalysisResult>;
    aiConfirm(request: AiConfirmRequest): Promise<AiApplyResult>;
}
export default MarketService;
export type * from './types.ts';
//# sourceMappingURL=index.d.ts.map