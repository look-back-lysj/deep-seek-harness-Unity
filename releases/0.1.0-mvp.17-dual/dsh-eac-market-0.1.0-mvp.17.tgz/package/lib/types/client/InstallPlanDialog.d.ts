import type { CatalogCollectionView, CatalogPack, CatalogPlugin, InventoryItem, PlanCreateRequest, PlanResult, TaskState } from '../types.ts';
import { type MarketRemote } from './model.ts';
export interface PlanTarget {
    readonly plugin?: CatalogPlugin;
    readonly pack?: CatalogPack;
    readonly collection?: CatalogCollectionView;
    readonly plugins: readonly CatalogPlugin[];
}
export declare function planSelectionFor(plugin: CatalogPlugin, inventory: readonly InventoryItem[], tryUnverified: boolean): {
    pluginId: string;
    packageName: string;
    targetVersion: string;
    targetDigest: string;
    enabledIntent: boolean;
    tryUnverified: boolean;
};
export declare function planRequestFor(target: PlanTarget, inventory: readonly InventoryItem[], consent: boolean): PlanCreateRequest;
interface Props {
    readonly target: PlanTarget | undefined;
    readonly inventory: readonly InventoryItem[];
    readonly remote: MarketRemote;
    readonly open: boolean;
    readonly onClose: () => void;
    readonly onStarted: (task: TaskState, reveal?: boolean) => void;
    readonly onOpenOfficialPlugins?: (() => void) | undefined;
    readonly inventoryIssues?: readonly string[] | undefined;
}
/** Only safe package identities are exposed; unknown diagnostic text may contain local paths. */
export declare function inventoryIssueLabel(issue: string): string;
export declare function isEnvironmentPreflightBlock(result: PlanResult | undefined): boolean;
/** A blocked plan is about the selected target; unrelated inventory issues are advisory. */
export declare function PreflightBlockNotice({ result, onOpenOfficialPlugins, inventoryIssues }: {
    readonly result: Extract<PlanResult, {
        readonly status: 'blocked';
    }>;
    readonly onOpenOfficialPlugins?: (() => void) | undefined;
    readonly inventoryIssues?: readonly string[] | undefined;
}): React.JSX.Element;
export declare function nextPreflightRetry(value: number): number;
/** The retry action is explicit even when checkbox changes already trigger preflight. */
export declare function UnsafePlanReview({ consentRequired, onRetry }: {
    readonly consentRequired: boolean;
    readonly onRetry: () => void;
}): React.JSX.Element;
/** A distinct mounted session owns each target. A's late success can reconcile A's
 * inventory, but cannot close B's dialog or move its focus to the task drawer. */
export declare function InstallPlanDialog(props: Props): React.JSX.Element | null;
export {};
//# sourceMappingURL=InstallPlanDialog.d.ts.map