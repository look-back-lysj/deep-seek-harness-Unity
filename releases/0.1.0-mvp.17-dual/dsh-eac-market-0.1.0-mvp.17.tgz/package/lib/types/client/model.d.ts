import type { ApprovalChallenge, AuthorDraft, AuthorDraftInput, AuthorExportRequest, AuthorMediaReadRequest, AuthorMediaReadResult, CatalogPack, CatalogCollectionView, CatalogPlugin, CatalogPresentation, CatalogSnapshot, CatalogRefreshRequest, CatalogRefreshView, CatalogSourceView, CoreMaintenanceSnapshot, UpdateCheckResult, UpdatePolicySnapshot, UpdatePolicySaveRequest, CatalogRecommendation, ClientHandshakeRequest, ClientHandshakeResult, AiAnalyzeRequest, AiAnalysisResult, AiApplyResult, AiConfirmRequest, DiagnosticExport, EnvironmentHello, InventoryItem, InventorySnapshot, PlanCreateRequest, PlanResult, PluginActionRequest, PluginActionResult, ReadmeImportRequest, ReadmeImportResult, ReadmePreviewView, ReadmeApplyPreviewRequest, RemovePluginRequest, ResumeChallenge, TaskApprovalRequest, TaskCancelRequest, TaskEventPage, TaskEventRequest, TaskIdRequest, TaskItemStatus, TaskResumeRequest, TaskStartRequest, TaskState, TaskStatus, TransferBeginRequest, TransferChunkRequest, TransferResult, TransferChunkReadRequest, TransferChunkReadResult, TransferDisposeRequest, AuthorDraftDeleteRequest, VerificationState } from '@dsh-eac/market-core/contracts';
export declare const PROTOCOL_REFRESH_HINT = "\u8BF7\u5237\u65B0\u9875\u9762\u6216\u91CD\u65B0\u6253\u5F00\u5E02\u573A\uFF1B\u82E5\u4ECD\u4E0D\u517C\u5BB9\uFF0C\u8BF7\u66F4\u65B0\u5E02\u573A\u63D2\u4EF6\u540E\u91CD\u8BD5\u3002";
export declare class ClientCompatibilityError extends Error {
    constructor(reason: string);
}
/** 首次加载、同步与写入防护共用；兼容要求固定来自 adapter 自身版本文件。
 * hello 可缺少可选核心信息以保留读取能力，写入仍须通过完整握手。 */
export declare function assertCompatibleHello(hello: EnvironmentHello): void;
export interface MarketRemote {
    hello(): Promise<EnvironmentHello>;
    clientConnect?(request: ClientHandshakeRequest): Promise<ClientHandshakeResult>;
    catalog(): Promise<CatalogSnapshot>;
    inventory(): Promise<InventorySnapshot>;
    createPlan?(request: PlanCreateRequest): Promise<PlanResult>;
    startTask?(request: TaskStartRequest): Promise<TaskState>;
    getTask?(request: TaskIdRequest): Promise<TaskState>;
    listTasks?(): Promise<readonly TaskState[]>;
    taskEvents?(request: TaskEventRequest): Promise<TaskEventPage>;
    cancelTask?(request: TaskCancelRequest): Promise<TaskState>;
    approveTask?(request: TaskApprovalRequest): Promise<TaskState>;
    resumeTask?(request: TaskResumeRequest): Promise<TaskState>;
    setPluginEnabled?(request: PluginActionRequest): Promise<PluginActionResult>;
    removePlugin?(request: RemovePluginRequest): Promise<PluginActionResult>;
    listDrafts?(): Promise<readonly AuthorDraft[]>;
    getDraft?(id: string): Promise<AuthorDraft>;
    saveDraft?(request: AuthorDraftInput): Promise<AuthorDraft>;
    deleteDraft?(request: AuthorDraftDeleteRequest): Promise<boolean>;
    exportDraft?(request: AuthorExportRequest): Promise<TransferResult>;
    readMedia?(request: AuthorMediaReadRequest): Promise<AuthorMediaReadResult>;
    importReadme?(request: ReadmeImportRequest): Promise<ReadmeImportResult>;
    previewReadme?(request: ReadmeImportRequest): Promise<ReadmePreviewView>;
    applyReadmePreview?(request: ReadmeApplyPreviewRequest): Promise<ReadmeImportResult>;
    transferBegin?(request: TransferBeginRequest): Promise<TransferResult>;
    transferChunk?(request: TransferChunkRequest): Promise<TransferResult>;
    transferRead?(request: TransferChunkReadRequest): Promise<TransferChunkReadResult>;
    transferDispose?(request: TransferDisposeRequest): Promise<boolean>;
    refreshCatalog?(request?: CatalogRefreshRequest): Promise<CatalogRefreshView>;
    catalogSources?(): Promise<readonly CatalogSourceView[]>;
    agentForgeRefresh?(request: {
        readonly sourceId: string;
    }): Promise<CatalogRefreshView>;
    maintenanceStatus?(): Promise<CoreMaintenanceSnapshot>;
    checkUpdates?(request?: {
        readonly sourceId?: string;
        readonly refreshFirst?: boolean;
    }): Promise<UpdateCheckResult>;
    updatePolicyGet?(): Promise<UpdatePolicySnapshot>;
    updatePolicySave?(request: UpdatePolicySaveRequest): Promise<UpdatePolicySnapshot>;
    exportDiagnostic?(): Promise<DiagnosticExport>;
    aiAnalyze?(request: AiAnalyzeRequest): Promise<AiAnalysisResult>;
    aiConfirm?(request: AiConfirmRequest): Promise<AiApplyResult>;
}
export type PrimaryView = 'discover' | 'all' | 'mine';
export type SecondaryView = 'help' | 'settings' | 'author' | 'skins';
export type MarketView = PrimaryView | SecondaryView | 'detail' | 'extension';
/**
 * 记录进入完整插件目录时的用户意图。它只属于前端导航状态，
 * 不参与目录、安装或评分协议，方便返回时恢复上下文。
 */
export type BrowseNavigationSource = 'top-nav' | 'discover' | 'all' | 'mine' | 'detail' | 'skins' | 'secondary' | 'extension';
export type DiscoverNavigationSection = 'featured' | 'skins' | 'high-score-plugin' | 'high-score-skill' | 'rules';
export interface BrowseNavigationContext {
    readonly source: BrowseNavigationSource;
    readonly category?: string;
    readonly section?: DiscoverNavigationSection;
    readonly query?: string;
    readonly page: number;
    readonly scrollTop: number;
}
/** 完整的 Client 返回快照；不进入 Remote 或 Core 合同。 */
export interface NavigationSnapshot {
    readonly view: MarketView;
    readonly source: BrowseNavigationSource;
    readonly filters: PluginFilters;
    readonly availableOnly: boolean;
    readonly sort: BrowseSortMode;
    readonly page: number;
    readonly scrollTop: number;
    readonly section?: string | undefined;
}
export type LoadState = {
    readonly status: 'loading';
} | {
    readonly status: 'ready';
    readonly hello: EnvironmentHello;
    readonly catalog: CatalogSnapshot;
    readonly inventory: InventorySnapshot;
    readonly tasks: readonly TaskState[];
} | {
    readonly status: 'error';
    readonly message: string;
};
export interface PluginFilters {
    readonly query: string;
    readonly category: string;
    readonly verification: 'all' | VerificationState;
    readonly installed: 'all' | 'yes' | 'no';
}
export declare const EMPTY_FILTERS: PluginFilters;
export declare function normalize(value: string): string;
export declare function filterPlugins(plugins: readonly CatalogPlugin[], inventory: readonly InventoryItem[], filters: PluginFilters): readonly CatalogPlugin[];
export declare function categoriesOf(plugins: readonly CatalogPlugin[]): readonly string[];
export declare function isInstalled(inventory: readonly InventoryItem[], plugin: CatalogPlugin): InventoryItem | undefined;
export declare function verificationLabel(value: VerificationState): string;
export type PluginActionKind = 'manage' | 'install' | 'confirm' | 'blocked' | 'runtime-unavailable';
export interface PluginActionState {
    readonly kind: PluginActionKind;
    readonly label: string;
    readonly disabled: boolean;
    readonly reason?: string;
    readonly installed?: InventoryItem;
}
export declare function pluginActionState(plugin: CatalogPlugin, inventory: readonly InventoryItem[], options?: {
    readonly canInstall?: boolean;
    readonly canManage?: boolean;
}): PluginActionState;
export declare function installabilityLabel(value: CatalogPlugin['installability']): string;
export declare function taskStatusLabel(value: TaskStatus | 'cancelling'): string;
export declare function taskItemStatusLabel(value: TaskItemStatus): string;
export declare function taskTone(value: TaskStatus | 'cancelling'): 'success' | 'info' | 'warning' | 'danger' | 'neutral';
export declare function activeTasks(tasks: readonly TaskState[]): readonly TaskState[];
export declare function packPluginIds(pack: CatalogPack): readonly string[];
export declare function findPlugin(catalog: CatalogSnapshot, pluginId: string | undefined, version?: string): CatalogPlugin | undefined;
/** Default update suggestions require known compatibility and the registered
 * delivery of the same package/version/digest. Unknown compatibility is not a
 * default update recommendation; it remains available in explicit detail flows. */
export declare function latestCompatiblePlugin(catalog: CatalogSnapshot, packageName: string): CatalogPlugin | undefined;
export declare function presentationForPlugin(catalog: CatalogSnapshot, plugin: CatalogPlugin): CatalogPresentation | undefined;
export declare function summarizeInventory(item: InventoryItem): string;
export declare function readOnlyLabel(item: InventoryItem): string | undefined;
export declare function formatBytes(size: number | undefined): string;
export declare function packCoverageLabel(value: CatalogPack['execution']['coverage']): string;
export declare function approvalPackages(challenge: ApprovalChallenge | undefined): readonly string[];
export declare function resumePlugins(challenge: ResumeChallenge | undefined): readonly string[];
export declare function createIdempotencyKey(prefix: string): string;
export type BrowseSortMode = 'rules' | 'compatibility' | 'recommended';
export declare function compareVersions(left: string | undefined, right: string): number;
export declare function hasCatalogUpdate(installed: InventoryItem | undefined, plugin: CatalogPlugin): boolean;
export declare function taskStateIsNewer(current: TaskState | undefined, next: TaskState): boolean;
export declare function pluginActionFeedback(action: Pick<PluginActionResult, 'status' | 'changed' | 'error'>, enabled: boolean): {
    readonly tone: 'success' | 'warning' | 'danger' | 'neutral';
    readonly message: string;
};
export declare function isSystemInventoryItem(item: InventoryItem, plugin: CatalogPlugin | undefined): boolean;
export declare function partitionInventory(items: readonly InventoryItem[], plugins: readonly CatalogPlugin[]): {
    readonly userItems: readonly InventoryItem[];
    readonly systemItems: readonly InventoryItem[];
    readonly systemNeedsAttention: boolean;
    readonly systemAttentionCount: number;
};
export declare function recommendationMatches(record: CatalogRecommendation, plugin: CatalogPlugin): boolean;
export declare function browseSortPlugins(plugins: readonly CatalogPlugin[], mode?: BrowseSortMode, recommendations?: readonly CatalogRecommendation[]): readonly CatalogPlugin[];
export interface PlanRequestTicket {
    readonly generation: number;
    readonly targetKey: string;
}
export declare function planTargetSignature(target: {
    readonly plugin?: Pick<CatalogPlugin, 'id' | 'version' | 'artifactDigest' | 'verification'>;
    readonly pack?: Pick<CatalogPack, 'id' | 'version'>;
    readonly collection?: Pick<CatalogCollectionView, 'kind' | 'id' | 'version' | 'collectionDigest'>;
    readonly plugins: readonly Pick<CatalogPlugin, 'id' | 'version' | 'artifactDigest' | 'verification'>[];
}): string;
export declare class PlanRequestGuard {
    private generation;
    private targetKey;
    begin(targetKey: string): PlanRequestTicket;
    invalidate(): void;
    accept<T>(ticket: PlanRequestTicket, value: T): T | undefined;
}
/** Next steps stay understandable even when an older Host returns a machine enum. */
export declare function taskNextStep(task: TaskState): string;
export declare function isTaskSettled(task: TaskState): boolean;
//# sourceMappingURL=model.d.ts.map