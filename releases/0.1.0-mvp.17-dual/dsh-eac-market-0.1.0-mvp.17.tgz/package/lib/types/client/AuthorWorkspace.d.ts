import type { AuthorDraft, AuthorDraftInput } from '../types.ts';
import type { MarketRemote } from './model.ts';
import type { ExtensionDraftChange, ExtensionDraftRef } from './extensions/contract.ts';
export declare function draftInput(draft: AuthorDraft): AuthorDraftInput;
/** Local editing has no fallback storage with a fake saved status. A revision from
 * the Host is the sole authority for saved/overwritten state. */
export declare function AuthorWorkspace({ remote, supplemental, onDraftSnapshot, onDirtyChange, draftChange }: {
    remote: MarketRemote;
    supplemental?: React.ReactNode;
    onDraftSnapshot?: ((draft: ExtensionDraftRef | undefined) => void) | undefined;
    onDirtyChange?: ((dirty: boolean) => void) | undefined;
    draftChange?: ExtensionDraftChange | undefined;
}): React.JSX.Element;
//# sourceMappingURL=AuthorWorkspace.d.ts.map