import type { CatalogMedia, CatalogPlugin, InventoryItem, TransferResult } from '../types.ts';
import { type MarketRemote } from './model.ts';
export declare function errorMessage(error: unknown): string;
export declare function toneClass(tone: 'success' | 'info' | 'warning' | 'danger' | 'neutral'): string;
/** 状态标签始终携带文字；颜色只增强语义，不能成为唯一线索。 */
export declare function Status({ tone, children }: {
    readonly tone?: 'success' | 'info' | 'warning' | 'danger' | 'neutral';
    readonly children: React.ReactNode;
}): React.JSX.Element;
export declare function VerificationStatus({ value }: {
    readonly value: CatalogPlugin['verification'];
}): React.JSX.Element;
export declare function EmptyState({ title, description, action }: {
    readonly title: string;
    readonly description: string;
    readonly action?: React.ReactNode;
}): React.JSX.Element;
export declare function PluginCard({ plugin, inventory, onOpen, onInstall, onManage, canInstall }: {
    readonly plugin: CatalogPlugin;
    readonly inventory: readonly InventoryItem[];
    readonly onOpen: (plugin: CatalogPlugin) => void;
    readonly onInstall: (plugin: CatalogPlugin) => void;
    /** 已安装且主控接好管理入口时启用；缺入口时保留原有 disabled“已安装”。 */
    readonly onManage?: (() => void) | undefined;
    readonly canInstall?: boolean;
}): React.JSX.Element;
export { InstallPlanDialog, planSelectionFor, type PlanTarget } from './InstallPlanDialog.tsx';
export { TaskDrawer } from './TaskDrawer.tsx';
export declare function InventoryCard({ item, catalogPlugin, showCatalogNotice, onToggle, onRemove, onUpdate, updatePlugin, onOpenOfficialPlugins, busy }: {
    readonly item: InventoryItem;
    readonly catalogPlugin: CatalogPlugin | undefined;
    /** 普通卡片默认展示目录缺失说明；系统分组由顶部统一说明一次。 */
    readonly showCatalogNotice?: boolean;
    readonly onToggle: (item: InventoryItem, enabled: boolean) => void;
    readonly onRemove: (item: InventoryItem) => void;
    readonly onUpdate?: (item: InventoryItem, plugin: CatalogPlugin) => void;
    readonly updatePlugin?: CatalogPlugin | undefined;
    readonly onOpenOfficialPlugins?: (() => void) | undefined;
    readonly busy?: boolean;
}): React.JSX.Element;
/** 加载失败不是空白图块：保留来源、真实图片说明，并提供可重复尝试的恢复入口。 */
export declare function ScreenshotFailure({ media, onRetry }: {
    readonly media: CatalogMedia;
    readonly onRetry: (media: CatalogMedia) => void;
}): React.JSX.Element;
export declare function ScreenshotGallery({ screenshots }: {
    readonly screenshots: CatalogPlugin['screenshots'];
}): React.JSX.Element | null;
export declare function FileTransferField({ remote, purpose, label, accept, onComplete }: {
    readonly remote: MarketRemote;
    readonly purpose: 'draft-media' | 'author-import';
    readonly label: string;
    readonly accept: string;
    readonly onComplete: (result: TransferResult, file: File) => void;
}): React.JSX.Element;
export declare function SearchField({ value, onChange }: {
    readonly value: string;
    readonly onChange: (value: string) => void;
}): React.JSX.Element;
export declare function formatTransferStatus(result: TransferResult | undefined): string;
//# sourceMappingURL=components.d.ts.map