import type { CatalogPack, CatalogCollectionView, CatalogPlugin, CatalogPresentation, CatalogSnapshot, InventoryItem } from '../types.ts';
import { type MarketRemote, type MarketView, type PrimaryView } from './model.ts';
import { type SkinServiceBridge } from './skin-service.ts';
import { type ExtensionContext, type ExtensionSlot, type MarketExtensionHost } from './extensions/contract.ts';
export type { MarketRemote } from './model.ts';
export interface MarketPageProps {
    readonly remote: MarketRemote;
    readonly skinService?: SkinServiceBridge | undefined;
    readonly onOpenOfficialPlugins?: (() => void) | undefined;
    readonly homeSupplemental?: React.ReactNode;
    readonly authorSupplemental?: React.ReactNode;
    readonly detailSupplemental?: ((plugin: CatalogPlugin) => React.ReactNode) | undefined;
    readonly extensions?: MarketExtensionHost | undefined;
    /** E supplies its guarded renderer. No contribution is invoked directly here. */
    readonly renderExtensionSurface?: ((props: {
        host: MarketExtensionHost;
        slot: ExtensionSlot;
        context: Readonly<ExtensionContext>;
        pageId?: string | undefined;
    }) => React.ReactNode) | undefined;
}
export declare function detailTab(origin: PrimaryView | 'skins'): PrimaryView;
export declare function applyBrowseChange(change: () => void, resetPage: () => void): void;
export declare function runAfterNextFrame(callback: () => void): void;
export declare function restoreDetailReturnFocus(trigger: HTMLElement | null | undefined, scrollContainer: HTMLElement | null | undefined, origin: PrimaryView | 'skins', doc?: Document | undefined): void;
export declare function packPlugins(pack: CatalogPack, catalogPlugins: readonly CatalogPlugin[]): readonly CatalogPlugin[];
export declare function MarketPage({ remote, skinService, onOpenOfficialPlugins, homeSupplemental, authorSupplemental, detailSupplemental, extensions, renderExtensionSurface }: MarketPageProps): React.JSX.Element;
export declare function MarketFrame({ view, activeCount, onNavigate, onTasks, onMore, moreMenu, onSecondary, activeTab, scrollRef, children, moreSupplemental, transitionPhase }: {
    readonly view: MarketView;
    readonly activeCount: number;
    readonly onNavigate: (view: PrimaryView) => void;
    readonly onTasks: () => void;
    readonly onMore: () => void;
    readonly moreMenu: boolean;
    readonly onSecondary: (view: 'help' | 'settings' | 'author') => void;
    readonly activeTab?: PrimaryView | undefined;
    readonly moreSupplemental?: React.ReactNode;
    readonly transitionPhase?: 'idle' | 'entering';
    readonly scrollRef?: React.Ref<HTMLDivElement>;
    readonly children: React.ReactNode;
}): React.JSX.Element;
export declare function DiscoverView({ catalog, inventory, onOpen, onInstall, onPack, onCollection, onBrowse, onHelp, onSettings, onManage, skinEntry, supplemental }: {
    readonly catalog: CatalogSnapshot;
    readonly inventory: readonly InventoryItem[];
    readonly onOpen: (plugin: CatalogPlugin) => void;
    readonly onInstall: (plugin: CatalogPlugin) => void;
    readonly onPack: (pack: CatalogPack) => void;
    readonly onCollection?: ((collection: CatalogCollectionView) => void) | undefined;
    readonly onBrowse: (category?: string) => void;
    readonly onHelp: () => void;
    readonly onSettings?: (() => void) | undefined;
    readonly onManage?: (() => void) | undefined;
    readonly skinEntry?: React.ReactNode;
    readonly supplemental?: React.ReactNode;
}): React.JSX.Element;
export declare function DetailView({ plugin, presentation, inventory, onBack, backLabel, onInstall, onUpdate, updatePlugin, canInstall, onOpenOfficialPlugins, supplemental }: {
    readonly plugin: CatalogPlugin;
    readonly presentation: CatalogPresentation | undefined;
    readonly inventory: readonly InventoryItem[];
    readonly onBack: () => void;
    readonly backLabel?: string | undefined;
    readonly onInstall: (plugin: CatalogPlugin) => void;
    readonly onUpdate?: (plugin: CatalogPlugin) => void;
    readonly updatePlugin?: CatalogPlugin | undefined;
    readonly canInstall?: boolean;
    readonly onOpenOfficialPlugins?: (() => void) | undefined;
    readonly supplemental?: React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=MarketPage.d.ts.map