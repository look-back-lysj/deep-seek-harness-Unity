import type { InstallPlan, InstallPlanItem, PackExecutionEdge } from '../types.ts';
export interface PlanReview {
    readonly executable: readonly InstallPlanItem[];
    readonly skipped: readonly InstallPlanItem[];
    readonly dependencyPaused: readonly InstallPlanItem[];
    readonly unsafe: readonly InstallPlanItem[];
    readonly canConfirm: boolean;
}
/** Projects a Host plan for confirmation, without editing the sealed plan or
 * choosing a subset to execute. Partial execution requires the Host to mark unsafe
 * items blocked. The executor remains the authority for dependency execution. */
export declare function reviewInstallPlan(plan: InstallPlan, group: boolean, edges: readonly PackExecutionEdge[], _consent?: boolean): PlanReview;
export declare function blockerExplanation(item: InstallPlanItem): string;
//# sourceMappingURL=plan-review.d.ts.map