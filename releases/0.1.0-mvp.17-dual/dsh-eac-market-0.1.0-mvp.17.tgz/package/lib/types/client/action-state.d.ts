import type { PluginActionResult, TaskState } from '../types.ts';
export type ActionLifecycleStatus = 'idle' | 'preparing' | 'running' | 'completed' | 'partial' | 'failed' | 'unknown' | 'needs-recheck';
export interface ActionFeedbackState {
    readonly status: ActionLifecycleStatus;
    readonly label: string;
    readonly message: string;
    readonly nextStep?: string;
    readonly retryable?: boolean;
}
export declare function idleActionFeedback(): ActionFeedbackState;
export declare function preparingActionFeedback(label: string): ActionFeedbackState;
export declare function runningActionFeedback(label: string): ActionFeedbackState;
export declare function completedActionFeedback(label: string, message: string, nextStep?: string): ActionFeedbackState;
export declare function partialActionFeedback(label: string, message: string, nextStep: string): ActionFeedbackState;
export declare function failedActionFeedback(label: string, error: unknown, nextStep: string, retryable?: boolean): ActionFeedbackState;
export declare function unknownActionFeedback(label: string, message: string, nextStep: string): ActionFeedbackState;
export declare function needsRecheckActionFeedback(label: string, message: string, nextStep: string, retryable?: boolean): ActionFeedbackState;
export declare function pluginActionFeedbackState(action: Pick<PluginActionResult, 'status' | 'error'>, label: string, successMessage: string): ActionFeedbackState;
export declare function taskActionFeedback(task: TaskState, label: string): ActionFeedbackState;
export declare function feedbackTone(status: ActionLifecycleStatus): 'success' | 'info' | 'warning' | 'danger' | 'neutral';
export declare function feedbackStatusLabel(status: ActionLifecycleStatus): string;
//# sourceMappingURL=action-state.d.ts.map