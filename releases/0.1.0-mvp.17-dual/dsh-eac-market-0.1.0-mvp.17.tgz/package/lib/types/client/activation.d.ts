import { type ComponentType } from 'react';
import type { Context } from '@deepseek-ai/cordis';
import type { MainPanelId } from '@deepseek-ai/dsh-client-ui-layout/client';
import { type MarketRemote } from './model.ts';
import type { MarketPageProps } from './MarketPage.tsx';
import type { SkinServiceBridge } from './skin-service.ts';
/** Optional Cordis dependency: installing/removing the loader updates the page
 * without turning the skin loader into a mandatory market dependency. */
export declare function attachSkinService(ctx: Context): SkinServiceBridge & {
    dispose(): Promise<void>;
};
export declare const PANEL_ID: MainPanelId;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        eacMarket: 'panel' | 'title';
    }
}
export interface Disposer {
    (): void | Promise<void>;
}
export interface ActivationComponents {
    readonly MarketPage: ComponentType<MarketPageProps>;
    readonly Icon: ComponentType;
}
export declare function remoteFacade(raw: unknown): MarketRemote;
/**
 * Mount the generated Remote contribution before reading its namespace. The
 * namespace is created by `$mount`; reading it earlier always fails even when
 * the Host MarketService itself is healthy.
 */
export declare function activateMarketClient(ctx: Context, remoteContribution: unknown, components: ActivationComponents): Promise<Disposer>;
//# sourceMappingURL=activation.d.ts.map