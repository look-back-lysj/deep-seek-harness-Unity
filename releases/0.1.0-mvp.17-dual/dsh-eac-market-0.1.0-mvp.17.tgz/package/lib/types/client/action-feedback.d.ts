import type { ReactNode } from 'react';
import { type ActionFeedbackState } from './action-state.ts';
export declare function ActionFeedback({ state, onRetry, onRefresh, onDismiss, children }: {
    readonly state: ActionFeedbackState;
    readonly onRetry?: (() => void) | undefined;
    readonly onRefresh?: (() => void) | undefined;
    readonly onDismiss?: (() => void) | undefined;
    readonly children?: ReactNode;
}): React.JSX.Element | null;
//# sourceMappingURL=action-feedback.d.ts.map