import { type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode } from 'react';
export type ButtonVariant = 'primary' | 'ghost' | 'outline' | 'toolbar';
export declare function Button({ variant, size, className, children, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & {
    readonly variant?: ButtonVariant;
    readonly size?: 'sm' | 'md';
}): React.JSX.Element;
export declare function Input({ className, ...rest }: InputHTMLAttributes<HTMLInputElement>): React.JSX.Element;
export declare function Tag({ tone, className, children }: {
    readonly tone?: 'outline' | 'solid' | 'neutral' | 'quiet' | 'success' | 'info' | 'warning' | 'danger';
    readonly className?: string;
    readonly children?: ReactNode;
}): React.JSX.Element;
export declare function Pill({ active, className, children, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & {
    readonly active?: boolean;
}): React.JSX.Element;
export declare function Modal({ open, onClose, title, description, children, footer, closeLabel, className, contentClassName }: {
    readonly open: boolean;
    readonly onClose: () => void;
    readonly title: string;
    readonly description?: string;
    readonly children?: ReactNode;
    readonly footer?: ReactNode;
    readonly closeLabel: string;
    readonly className?: string;
    readonly contentClassName?: string;
}): React.JSX.Element | null;
export declare function MarkdownText({ text, labels, mediaUrls }: {
    readonly text: string;
    readonly labels: unknown;
    readonly mediaUrls?: Readonly<Record<string, string>>;
}): React.JSX.Element;
//# sourceMappingURL=ui.d.ts.map