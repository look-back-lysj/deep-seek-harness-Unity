import type { CapabilityName, CatalogRefreshView } from '@dsh-eac/market-core/contracts';
import type { MarketRemote } from './model.ts';
export interface SettingsRemotePanelProps {
    readonly remote: MarketRemote;
    readonly capabilities?: readonly CapabilityName[];
    readonly environmentId?: string;
    readonly refreshBusy: boolean;
    readonly onRefreshSource: (sourceId: string) => Promise<CatalogRefreshView | undefined>;
}
export declare function SettingsRemotePanel({ remote, capabilities, environmentId, refreshBusy, onRefreshSource }: SettingsRemotePanelProps): React.JSX.Element;
//# sourceMappingURL=SettingsRemotePanel.d.ts.map