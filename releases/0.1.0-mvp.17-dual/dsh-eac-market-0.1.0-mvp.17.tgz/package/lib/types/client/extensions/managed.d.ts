/** Cooperative supervision for reviewed code. It cannot stop a blocked JS thread
 * or a Promise that ignores AbortSignal; it does stop accepting its late result.
 */
export type ManagedResult<T> = {
    readonly status: 'ok';
    readonly value: T;
} | {
    readonly status: 'error' | 'aborted' | 'timeout';
};
export interface ManagedExtensionRuntime {
    readonly signal: AbortSignal;
    run<T>(work: (signal: AbortSignal) => T | PromiseLike<T>, accept?: (value: T) => unknown, timeoutMs?: number): Promise<ManagedResult<T>>;
    guard<Args extends unknown[]>(work: (...args: Args) => unknown): (...args: Args) => void;
    effect(setup: (signal: AbortSignal) => void | (() => unknown)): () => void;
    getSnapshot(): string | undefined;
    subscribe(listener: () => void): () => void;
    fail(code: string): void;
    /** React commit lease; tolerates StrictMode's immediate cleanup/setup replay. */
    retain(): () => void;
    dispose(): void;
}
export declare function createManagedExtensionRuntime(options?: {
    readonly signals?: readonly AbortSignal[] | undefined;
    readonly onIssue?: ((code: string) => unknown) | undefined;
    readonly timeoutMs?: number | undefined;
    readonly deferSignals?: boolean | undefined;
}): ManagedExtensionRuntime;
//# sourceMappingURL=managed.d.ts.map