/** Official 0.1.7-rc.2 adapter: runtime declaration != TypeScript SlotMap merge.
 * Only the market's existing main entry declares these children; we never claim root/main.
 */
import { type ReactNode } from 'react';
import type { Context } from '@deepseek-ai/cordis';
import type { PropsRenderSlots } from '@deepseek-ai/dsh-client-ui-slots';
import { type ExtensionSlot } from './contract.ts';
import { type MarketExtensionController } from './registry.ts';
import { type ExtensionSurfaceProps } from './surface.tsx';
export declare const EXTENSION_CHILDREN: Readonly<{
    readonly "eac.market.home.supplemental.section": Readonly<{
        kind: "list";
        scope: "root";
    }>;
    readonly "eac.market.extension.more": Readonly<{
        kind: "list";
        scope: "root";
    }>;
    readonly "eac.market.extension.page": Readonly<{
        kind: "keyed";
        scope: "root";
    }>;
    readonly "eac.market.detail.section": Readonly<{
        kind: "list";
        scope: "root";
    }>;
    readonly "eac.market.author.tool": Readonly<{
        kind: "list";
        scope: "root";
    }>;
}>;
/** Mirror only accepted registry records. Each inject waits for a real parent
 * declaration and re-registers after that declaration is torn down/recreated.
 */
export declare function attachDshSlots(ctx: Context, host: MarketExtensionController): () => void;
/** Owns host disposal and the restricted service publication. Call once from
 * the market client fiber after its required `slots` service is available.
 */
export declare function attachDshService(ctx: Context, host: MarketExtensionController): () => Promise<void>;
export type MarketExtensionSlotRenderer = PropsRenderSlots<ExtensionSlot>['renderSlot'];
/** Pass the real renderSlot received by the main-slot component, not ctx.slots.renderSlot
 * (that public service method only renders root). Compatible with C's existing seam.
 */
export declare function createDshExtensionRenderer(renderSlot: MarketExtensionSlotRenderer): (props: ExtensionSurfaceProps) => ReactNode;
//# sourceMappingURL=dsh.d.ts.map