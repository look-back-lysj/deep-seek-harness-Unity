import { type ReactNode } from 'react';
import { type ExtensionContext, type ExtensionSlot, type MarketExtensionHost, type RegisteredContribution } from './contract.ts';
import { type ManagedExtensionRuntime } from './managed.ts';
export interface ExtensionSurfaceProps {
    readonly host: MarketExtensionHost;
    readonly slot: ExtensionSlot;
    readonly context: Readonly<ExtensionContext>;
    /** The full registry key, never a naked author-supplied route. */
    readonly pageId?: string | undefined;
}
/** Wrap extension-owned event/Promise/effect work with this cooperative supervisor. */
export declare function useExtensionRuntime(): ManagedExtensionRuntime;
/** This wrapper alone enters official slots. Framework-injected props are discarded. */
export declare function ExtensionEntry({ host, entry, context }: {
    readonly host: MarketExtensionHost;
    readonly entry: RegisteredContribution;
    readonly context: Readonly<ExtensionContext>;
}): ReactNode;
export declare function ExtensionSurface(props: ExtensionSurfaceProps): ReactNode;
/** Exact function shape already accepted by C's MarketPage. */
export declare function renderExtensionSurface(props: ExtensionSurfaceProps): ReactNode;
//# sourceMappingURL=surface.d.ts.map