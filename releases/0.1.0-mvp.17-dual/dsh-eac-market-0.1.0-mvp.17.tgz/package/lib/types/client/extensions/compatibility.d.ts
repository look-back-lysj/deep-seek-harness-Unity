export declare function compatibleVersion(version: string, range: string): boolean;
//# sourceMappingURL=compatibility.d.ts.map