import { type ExtensionContext, type MarketExtensionHost, type RegisteredContribution } from './contract.ts';
import type { ManagedExtensionRuntime } from './managed.ts';
/** Pick fields explicitly. Even a wider runtime object supplied by the host
 * never forwards its Remote, Context, task methods or arbitrary extra fields.
 */
export declare function createContributionContext(host: MarketExtensionHost, entry: RegisteredContribution, source: () => Readonly<ExtensionContext>, runtime: ManagedExtensionRuntime): Readonly<ExtensionContext>;
//# sourceMappingURL=context.d.ts.map