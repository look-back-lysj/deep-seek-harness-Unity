import type { ExtensionDefinition, ExtensionOwnerScope, ExtensionRegistration } from './contract.ts';
import type { MarketExtensionController } from './registry.ts';
/** Builtins use the exact same validation and teardown path as external plugins. */
export declare function registerBuiltinExtension(host: MarketExtensionController, owner: ExtensionOwnerScope, definition: ExtensionDefinition): ExtensionRegistration;
//# sourceMappingURL=builtin.d.ts.map