import { type ExtensionCapability, type ExtensionDefinition, type ExtensionOwnerScope, type ExtensionRegistration, type MarketExtensionHost, type MarketExtensionService, type RegisteredContribution } from './contract.ts';
export interface ExtensionIssue {
    readonly code: string;
    readonly extensionId?: string | undefined;
    readonly contributionKey?: string | undefined;
}
export interface MarketExtensionOptions {
    readonly marketVersion: string;
    readonly dshVersion: string;
    readonly capabilities: readonly ExtensionCapability[];
    /** Codes only: arbitrary exception messages may contain private data. */
    readonly onIssue?: ((issue: Readonly<ExtensionIssue>) => unknown) | undefined;
}
export interface MarketExtensionController extends MarketExtensionHost {
    readonly service: MarketExtensionService;
    registerBuiltin(owner: ExtensionOwnerScope, definition: ExtensionDefinition): ExtensionRegistration;
    dispose(): void;
}
export declare const contributionSignal: (entry: RegisteredContribution) => AbortSignal | undefined;
export declare const reportExtensionIssue: (host: MarketExtensionHost, issue: ExtensionIssue) => void;
export declare function createMarketExtensionHost(input: MarketExtensionOptions): MarketExtensionController;
//# sourceMappingURL=registry.d.ts.map