import type { CatalogListing } from '../types.ts';
export declare function filterListings(listings: readonly CatalogListing[], query: string): readonly CatalogListing[];
/** Registration records are not installable releases. Never convert them into
 * CatalogPlugin or infer a version; retain this boundary even after searching.
 */
export declare function PendingListings({ listings, query }: {
    readonly listings: readonly CatalogListing[];
    readonly query: string;
}): React.JSX.Element | null;
//# sourceMappingURL=PendingListings.d.ts.map