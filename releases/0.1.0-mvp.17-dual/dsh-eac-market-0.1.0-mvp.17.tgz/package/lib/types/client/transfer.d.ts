import type { TransferBeginRequest, TransferResult } from '../types.ts';
import type { MarketRemote } from './model.ts';
export declare const DEFAULT_CHUNK_BYTES: number;
export interface FileBlock {
    readonly sequence: number;
    readonly data: string;
    readonly byteLength: number;
}
export declare function encodeBase64(bytes: Uint8Array): string;
export declare function blocksFromBytes(bytes: Uint8Array, chunkBytes?: number): readonly FileBlock[];
export declare function sha256Hex(bytes: Uint8Array): Promise<string>;
export interface UploadOptions {
    readonly purpose: TransferBeginRequest['purpose'];
    readonly targetId?: string;
    readonly expectedRevision?: string;
    readonly filename: string;
    readonly mediaType: string;
    readonly chunkBytes?: number;
    readonly onProgress?: (receivedBytes: number, totalBytes: number) => void;
}
export declare function uploadBytes(remote: MarketRemote, bytes: Uint8Array, options: UploadOptions): Promise<TransferResult>;
export declare function decodeBase64(text: string): Uint8Array;
/** Read the Host's real outbound bytes. Identity, sequence and size are checked on
 * every block; a partial response can never become a downloadable ZIP. */
export declare function readTransfer(remote: MarketRemote, transfer: TransferResult, maxBytes?: number): Promise<Uint8Array>;
export declare function saveBytes(bytes: Uint8Array, filename: string, type: string): void;
export declare function uploadFile(remote: MarketRemote, file: File, purpose: UploadOptions['purpose'], onProgress?: UploadOptions['onProgress']): Promise<TransferResult>;
//# sourceMappingURL=transfer.d.ts.map