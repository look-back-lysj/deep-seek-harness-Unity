import type { CatalogRefreshRequest, CatalogRefreshView, TaskState } from '@dsh-eac/market-core/contracts';
import { type LoadState, type MarketRemote } from './model.ts';
export declare class RequestTimeout extends Error {
}
/** A timeout stops waiting, never asserts that a remote write was cancelled. */
export declare function boundedRequest<T>(request: Promise<T>, label: string, timeoutMs?: number): Promise<T>;
export interface DataView {
    readonly state: LoadState;
    readonly notice: string;
    readonly paused: boolean;
}
interface Options {
    timeoutMs?: number;
    pollMs?: number;
    idleMs?: number;
    maxPolls?: number;
}
/** One lifecycle owns the reads. React renders cannot dispose a terminal inventory refresh.
 * Reads are serial, bounded and environment-scoped. listTasks also discovers other tabs' work.
 * On timeout we stop automatic reads instead of stacking requests against a stalled Host.
 */
export declare class MarketDataController {
    readonly remote: MarketRemote;
    private view;
    private listeners;
    private epoch;
    private stopped;
    private timer;
    private running;
    private inventoryRun;
    private inventoryVersion;
    private needsInventory;
    private cycles;
    private failures;
    private hidden;
    private refreshVersion;
    private readonly config;
    constructor(remote: MarketRemote, options?: Options);
    snapshot(): DataView;
    subscribe(listener: (view: DataView) => void): () => void;
    private publish;
    private read;
    start(): Promise<void>;
    stop(): void;
    setHidden(hidden: boolean): void;
    private ready;
    private schedule;
    sync(manual?: boolean): Promise<void>;
    private markInventoryDirty;
    private mergeTask;
    acceptTask(task: TaskState): void;
    refreshInventory(markDirty?: boolean): Promise<void>;
    private flushInventory;
    refreshCatalog(request?: CatalogRefreshRequest): Promise<CatalogRefreshView>;
}
export declare function useMarketData(remote: MarketRemote): DataView & {
    controller: MarketDataController;
};
export {};
//# sourceMappingURL=data-controller.d.ts.map