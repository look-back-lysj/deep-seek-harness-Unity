import type { CatalogPlugin, InventoryItem } from '../types.ts';
import type { CatalogSnapshot } from '../types.ts';
import { type SkinServiceBridge } from './skin-service.ts';
export interface SkinCenterProps {
    readonly catalog: CatalogSnapshot;
    readonly inventory: readonly InventoryItem[];
    readonly skinService?: SkinServiceBridge | undefined;
    readonly onBack: () => void;
    readonly onOpen: (plugin: CatalogPlugin) => void;
    readonly onInstall: (plugin: CatalogPlugin) => void;
    readonly onToggle: (item: InventoryItem, enabled: boolean) => void;
    readonly onRemove: (item: InventoryItem) => void;
    readonly onOpenOfficialPlugins?: (() => void) | undefined;
    readonly managementBusy?: boolean;
    readonly canInstall: boolean;
}
export declare function SkinCenterEntry({ plugins, inventory, onOpen }: {
    readonly plugins: readonly CatalogPlugin[];
    readonly inventory: readonly InventoryItem[];
    readonly onOpen: () => void;
}): React.JSX.Element;
export declare function SkinCenter({ catalog, inventory, skinService, onBack, onOpen, onInstall, onToggle, onRemove, onOpenOfficialPlugins, managementBusy, canInstall }: SkinCenterProps): React.JSX.Element;
//# sourceMappingURL=SkinCenter.d.ts.map