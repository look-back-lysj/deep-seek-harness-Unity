import type { CatalogPlugin, InventoryItem } from '../types.ts';
import type { SkinRuntimeInfo } from './skin-service.ts';
export declare function isSkinPlugin(plugin: CatalogPlugin): boolean;
export declare function skinCatalogForInventory(item: InventoryItem, plugins: readonly CatalogPlugin[]): CatalogPlugin | undefined;
export declare function skinSwitchBlockReason(item: InventoryItem, plugin: CatalogPlugin, info: SkinRuntimeInfo | undefined): string | undefined;
//# sourceMappingURL=skin-model.d.ts.map