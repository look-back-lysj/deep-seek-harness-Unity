import type { TaskState } from '../types.ts';
import { type MarketRemote } from './model.ts';
interface Props {
    readonly open: boolean;
    readonly tasks: readonly TaskState[];
    readonly onClose: () => void;
    readonly remote: MarketRemote;
    readonly onChanged: (task: TaskState) => void;
    readonly onRefresh?: () => void;
    readonly onOpenOfficialPlugins?: (() => void) | undefined;
}
export declare function TaskDrawer({ open, tasks, ...props }: Props): React.JSX.Element | null;
export {};
//# sourceMappingURL=TaskDrawer.d.ts.map