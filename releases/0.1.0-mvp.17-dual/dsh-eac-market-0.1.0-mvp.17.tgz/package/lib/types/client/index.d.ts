import type { Context } from '@deepseek-ai/cordis';
import { type Disposer } from './activation.ts';
export { PANEL_ID } from './activation.ts';
export declare const inject: string[];
export declare function apply(ctx: Context): Promise<Disposer>;
//# sourceMappingURL=index.d.ts.map