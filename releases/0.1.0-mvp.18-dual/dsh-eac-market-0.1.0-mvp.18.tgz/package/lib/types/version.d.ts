/** Release identity checked against package.json by package verification. */
export declare const ADAPTER_VERSION = "0.1.0-mvp.18";
/** These are the adapter's compiled requirements, not values read from a
 * potentially newer core at runtime. Widen them only with compatibility tests. */
export declare const REQUIRED_CORE_API_VERSION = "1.0.0";
export declare const ADAPTER_PROTOCOL_VERSION = "2.0.0";
//# sourceMappingURL=version.d.ts.map