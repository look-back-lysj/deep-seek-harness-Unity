export interface HttpProxyConfiguration {
    /** 只接受 HTTP(S) 代理 URL；认证可写在 URL 中，但绝不写入诊断或进度。 */
    readonly httpProxy?: string;
    readonly httpsProxy?: string;
    /** 逗号分隔的主机名/IP/可选端口；支持 *、.domain、*.domain。 */
    readonly noProxy?: string;
}
export interface RemoteSecurityOptions {
    readonly allowPrivateHosts?: boolean;
    readonly maxRedirects?: number;
    /** 兼容旧调用方：一次安全请求及其响应正文的总时间上限。 */
    readonly timeoutMs?: number;
    /** DNS 检查、连接、TLS 与拿到响应头的预算。 */
    readonly headersTimeoutMs?: number;
    /** 流式正文连续无数据的上限。 */
    readonly bodyIdleTimeoutMs?: number;
    readonly lookup?: (hostname: string) => Promise<readonly string[]>;
    /** 网络配置只由 Host 注入，不从目录或前端数据读取。 */
    readonly proxy?: HttpProxyConfiguration;
    /** 返回 Undici 兼容的 per-request dispatcher；不修改全局 dispatcher。 */
    readonly dispatcherForProxy?: (proxyUrl: URL) => unknown;
}
export interface SafeFetchOptions extends RemoteSecurityOptions {
    readonly headers?: Record<string, string>;
    readonly fetch?: typeof fetch;
    readonly signal?: AbortSignal | undefined;
    /** 目录读者可进一步要求每跳都属于维护者登记的确切 URL。 */
    readonly validateRedirect?: (url: URL) => void;
    /** Cache only: allow a small number of non-2xx protocol responses for validation. */
    readonly allowStatuses?: readonly number[];
}
export declare class DeliverySecurityError extends Error {
    readonly code: string;
    readonly status?: number;
    readonly retryAfterMs?: number;
    constructor(code: string, message: string, details?: {
        readonly status?: number;
        readonly retryAfterMs?: number;
    });
}
export declare function isPrivateAddress(address: string): boolean;
export declare function assertSafeRemoteUrl(input: string | URL, options?: RemoteSecurityOptions): Promise<URL>;
/** 中止等待也用于 DNS 和自定义 Reader；取消后不能继续尝试镜像。 */
export declare function withAbort<T>(operation: Promise<T>, signal?: AbortSignal): Promise<T>;
export declare function matchesNoProxy(hostname: string, port: string, noProxy?: string): boolean;
export declare function readLimitedResponse(response: Response, maxBytes: number, signal?: AbortSignal, bodyIdleTimeoutMs?: number): Promise<Uint8Array>;
/**
 * 只做有界的 HTTP GET/重定向检查。调用方必须继续限制响应正文并核对摘要；
 * HTTP 200 从来不代表制品已经验证。代理通过 per-request Undici dispatcher 注入，不改进程全局设置。
 */
export declare function safeFetch(input: string | URL, options?: SafeFetchOptions): Promise<Response>;
//# sourceMappingURL=security.d.ts.map