export interface TgzLimits {
    readonly maxCompressedBytes?: number;
    readonly maxExpandedBytes?: number;
    readonly maxEntryBytes?: number;
    readonly maxEntries?: number;
    readonly maxPackageJsonBytes?: number;
}
export declare const DEFAULT_TGZ_LIMITS: Required<TgzLimits>;
export interface ExpectedTgzIdentity {
    readonly artifactDigest: string;
    readonly packageName: string;
    readonly version: string;
    readonly requireBundle?: boolean;
}
export interface VerifiedTgz {
    readonly path: string;
    readonly artifactDigest: string;
    readonly size: number;
    readonly packageName: string;
    readonly version: string;
    readonly entryCount: number;
    readonly expandedBytes: number;
    readonly bundlePatch?: string;
    /** 原始 package.json 字节的文本和普通文件表只供 Host 内容检查，不作运行证明。 */
    readonly packageJson: string;
    readonly files: readonly string[];
}
export declare class TgzVerificationError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare function verifyTgzFile(path: string, expected: ExpectedTgzIdentity, options?: TgzLimits & {
    readonly signal?: AbortSignal | undefined;
}): Promise<VerifiedTgz>;
//# sourceMappingURL=tgz.d.ts.map