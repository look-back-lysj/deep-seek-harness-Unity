import type { OfflinePackArtifact } from '../contracts/types.ts';
import type { OfflinePackContents } from '../catalog/offline-pack.ts';
export declare class OfflineArtifactError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export interface MaterializedOfflineArtifact {
    readonly digest: string;
    readonly path: string;
    readonly size: number;
}
/** 只写入 manifest 声明且摘要相符的制品；已存在且内容不符时拒绝覆盖。 */
export declare function materializeOfflineArtifacts(contents: Pick<OfflinePackContents, 'artifacts' | 'artifactEntries'>, cacheDir: string): readonly MaterializedOfflineArtifact[];
/** 在构建离线包索引时核对一个制品声明，供上层生成 manifest 使用。 */
export declare function describeOfflineArtifact(bytes: Uint8Array, filename: string, relativePath?: string): OfflinePackArtifact;
//# sourceMappingURL=offline-pack.d.ts.map