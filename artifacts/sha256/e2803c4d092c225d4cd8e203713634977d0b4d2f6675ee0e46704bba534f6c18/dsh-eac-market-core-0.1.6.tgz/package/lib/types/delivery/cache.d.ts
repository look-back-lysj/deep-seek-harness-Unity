import type { CatalogDelivery, DeliverySource } from '../contracts/types.ts';
import { type RemoteSecurityOptions } from './security.ts';
import { type TgzLimits, type VerifiedTgz } from './tgz.ts';
export type CacheReferenceKind = 'active-task' | 'installed';
export interface CacheReference {
    readonly id: string;
    readonly kind: CacheReferenceKind;
    readonly createdAt: string;
}
export interface ArtifactCacheOptions extends RemoteSecurityOptions {
    readonly cacheDir: string;
    readonly maxCompressedBytes?: number;
    readonly allowLocalFileSources?: readonly string[];
    readonly fetch?: typeof fetch;
    readonly now?: () => Date;
    readonly maxDownloadTimeoutMs?: number;
    readonly maxDownloadTotalMs?: number;
    readonly downloadBaseTimeoutMs?: number;
    readonly minDownloadBytesPerSecond?: number;
    readonly maxRetries?: number;
    readonly retryBaseDelayMs?: number;
    readonly retryMaxDelayMs?: number;
    readonly progressIntervalMs?: number;
}
export type ArtifactDownloadStage = 'connecting' | 'downloading' | 'retrying' | 'verifying' | 'completed' | 'failed' | 'cancelled';
export interface ArtifactDownloadProgress {
    readonly stage: ArtifactDownloadStage;
    readonly pluginId: string;
    readonly packageName: string;
    readonly version: string;
    readonly artifactDigest: string;
    readonly sourceIndex: number;
    readonly sourceCount: number;
    readonly sourceKind: DeliverySource['kind'];
    readonly attempt: number;
    readonly receivedBytes: number;
    readonly totalBytes?: number;
    readonly resumed: boolean;
}
export interface DownloadArtifactOptions {
    readonly signal?: AbortSignal | undefined;
    readonly requireBundle?: boolean;
    readonly referenceId: string;
    readonly referenceKind: CacheReferenceKind;
    readonly tgzLimits?: TgzLimits;
    readonly allowLocalFileSources?: readonly string[];
    readonly onProgress?: ((progress: ArtifactDownloadProgress) => void | Promise<void>) | undefined;
}
export interface DeliveryAttempt {
    readonly source: DeliverySource;
    readonly status: 'accepted' | 'network-failed' | 'digest-mismatch' | 'unsafe' | 'identity-mismatch';
    readonly reason?: string;
}
export interface AcquiredArtifact {
    readonly verified: VerifiedTgz;
    readonly localPath: string;
    readonly attempts: readonly DeliveryAttempt[];
}
export declare class DeliveryError extends Error {
    readonly code: string;
    readonly attempts: readonly DeliveryAttempt[];
    constructor(code: string, message: string, attempts?: readonly DeliveryAttempt[]);
}
export declare class ArtifactCache {
    private readonly root;
    private readonly options;
    private readonly now;
    private readonly inFlightDownloads;
    constructor(options: ArtifactCacheOptions);
    private get referencesPath();
    private readReferences;
    retain(digest: string, reference: Omit<CacheReference, 'createdAt'>): void;
    release(digest: string, referenceId: string): void;
    pathFor(digest: string): string;
    pruneUnreferenced(before: Date): readonly string[];
    private allowedLocalRoots;
    private localFileBytes;
    private partLocation;
    private readPart;
    private savePart;
    private clearPart;
    private securityOptions;
    private calculatedSourceBudget;
    private report;
    private writeChunk;
    private downloadRemoteToPart;
    download(delivery: CatalogDelivery, options: DownloadArtifactOptions): Promise<AcquiredArtifact>;
    private downloadExclusive;
}
/** Host-only result转UI时只交摘要/大小/来源，不交本机绝对路径。 */
export declare function publicArtifactView(artifact: AcquiredArtifact): Omit<VerifiedTgz, 'path' | 'packageJson' | 'files'>;
//# sourceMappingURL=cache.d.ts.map