export declare const desktopHttpsFetch: typeof fetch;
//# sourceMappingURL=https-reader.d.ts.map