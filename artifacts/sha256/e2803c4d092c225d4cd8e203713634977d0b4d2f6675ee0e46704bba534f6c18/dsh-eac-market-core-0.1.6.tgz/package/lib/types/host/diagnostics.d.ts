import type { AiAnalyzeRequest, CatalogSnapshot, DeliverySource, DiagnosticExport, InventorySnapshot, TaskState } from '../contracts/types.ts';
export declare function sourceIdentity(source: DeliverySource): string;
export declare function sanitizeDiagnostic(value: string, limit?: number): string;
export declare function diagnosticDigest(diagnostic: DiagnosticExport): string;
export declare function collectDiagnostics(input: {
    readonly environmentId: string;
    readonly hostVersion: string;
    readonly marketVersion: string;
    readonly selection?: AiAnalyzeRequest | undefined;
    readonly tasks: readonly TaskState[];
    readonly inventory?: InventorySnapshot | undefined;
    readonly catalog?: CatalogSnapshot | undefined;
    readonly errors?: readonly string[] | undefined;
}): DiagnosticExport;
//# sourceMappingURL=diagnostics.d.ts.map