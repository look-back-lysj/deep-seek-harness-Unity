import type { Context } from '@deepseek-ai/cordis';
import type { AiAnalyzeRequest, AiAnalysisResult, AiApplyResult, AiConfirmRequest, AuthorDraft, AuthorDraftDeleteRequest, AuthorDraftInput, AuthorExportRequest, AuthorMediaReadRequest, AuthorMediaReadResult, CatalogRefreshRequest, CatalogRefreshView, CatalogSourceView, CoreMaintenanceSnapshot, MarketCatalogSource, UpdatePolicySnapshot, UpdatePolicySaveRequest, DiagnosticExport, PlanCreateRequest, PlanResult, PluginActionResult, PluginActionRequest, ReadmeImportRequest, ReadmeImportResult, ReadmePreviewView, ReadmeApplyPreviewRequest, RemovePluginRequest, TaskApprovalRequest, TaskCancelRequest, TaskEventPage, TaskEventRequest, TaskIdRequest, TaskResumeRequest, TaskStartRequest, TaskState, TransferBeginRequest, TransferChunkReadRequest, TransferChunkReadResult, TransferChunkRequest, TransferResult } from '../contracts/types.ts';
import { CatalogRepository } from '../catalog/store.ts';
import { type CatalogSourceIdentity } from '../catalog/source.ts';
import { InstallTaskManager } from '../core/task-manager.ts';
import { type AgentForgeSourceOptions } from '../catalog/agent-forge.ts';
import { OfficialHostPort } from '../adapters/dsh/host-port.ts';
import { CatalogArtifactPort } from '../adapters/dsh/artifact-adapter.ts';
import type { RemoteSecurityOptions } from '../delivery/security.ts';
type RuntimeNetworkOptions = Pick<RemoteSecurityOptions, 'proxy' | 'dispatcherForProxy' | 'headersTimeoutMs' | 'bodyIdleTimeoutMs' | 'timeoutMs' | 'maxRedirects' | 'lookup'> & {
    readonly fetch?: typeof fetch;
};
import { AuthorPackageService, ReadmeImporter, TransferManager } from '../authoring/index.ts';
export interface RuntimeIdentity {
    readonly environmentId: string;
    readonly profileName: string;
    readonly hostVersion: string;
    readonly hostId?: string;
}
export interface RuntimeOptions {
    readonly catalogSources?: readonly CatalogSourceIdentity[];
    /** Host-maintained Agent Forge sources; source URLs are never accepted from Remote input. */
    readonly agentForgeSources?: readonly MarketCatalogSource[];
    /** Host-only transport, trust and authorized local import roots. */
    readonly agentForgeSourceOptions?: AgentForgeSourceOptions;
    /** Host-only network transport settings; never accepted from Client or catalog data. */
    readonly network?: RuntimeNetworkOptions;
    /** Adapter 读取其随包 data/index.json 后提供原始字节；core 不猜资源路径。 */
    readonly embeddedCatalogBytes?: Uint8Array;
    /** 兼容合成测试的对象注入；生产 adapter 应使用 embeddedCatalogBytes。 */
    readonly embeddedCatalog?: unknown;
    readonly marketVersion?: string;
}
export declare class MarketRuntime {
    readonly identity: RuntimeIdentity;
    readonly host: OfficialHostPort;
    readonly catalog: CatalogRepository;
    readonly artifacts: CatalogArtifactPort;
    readonly tasks: InstallTaskManager;
    readonly authoring: AuthorPackageService;
    readonly readme: ReadmeImporter;
    readonly transfers: TransferManager;
    private recovery;
    private recoveryError;
    private readonly sources;
    private readonly agentForgeSources;
    private readonly agentForgeCatalogs;
    private readonly agentForgeStatus;
    private readonly updatePolicy;
    private readonly updateCheckScheduler;
    private readonly agentForgeSourceOptions;
    private readonly files;
    private readonly taskStore;
    private readonly aiProposals;
    private readonly context;
    private readonly marketVersion;
    private readonly artifactCacheDir;
    private readonly network;
    private readonly maintenanceIntents;
    constructor(ctx: Context, identity: RuntimeIdentity, dataDirectory: string, options?: RuntimeOptions);
    private ensureWriteReady;
    private get assistant();
    private planPath;
    private savePlan;
    private loadPlan;
    catalogView(): import('../contracts/types.ts').CatalogSnapshot;
    capabilities(): readonly import('../contracts/types.ts').CapabilityName[];
    catalogSources(): Promise<readonly CatalogSourceView[]>;
    agentForgeRefresh(request: {
        readonly sourceId: string;
    }): Promise<CatalogRefreshView>;
    catalogRefresh(request?: CatalogRefreshRequest): Promise<CatalogRefreshView>;
    planCreate(request: PlanCreateRequest, callerId?: string, preferredSource?: {
        readonly packageName: string;
        readonly sourceId: string;
    }): Promise<PlanResult>;
    taskStart(request: TaskStartRequest, callerId?: string): Promise<TaskState>;
    taskGet(request: TaskIdRequest): Promise<TaskState>;
    taskList(): Promise<readonly TaskState[]>;
    taskEvents(request: TaskEventRequest): Promise<TaskEventPage>;
    taskApproveBuilds(request: TaskApprovalRequest): Promise<TaskState>;
    taskResume(request: TaskResumeRequest): Promise<TaskState>;
    taskCancel(request: TaskCancelRequest): Promise<TaskState>;
    pluginSetEnabled(request: PluginActionRequest): Promise<PluginActionResult>;
    pluginRemove(request: RemovePluginRequest): Promise<PluginActionResult>;
    /** Produces a fresh Core-owned maintenance snapshot after task recovery. */
    readonly maintenanceStatus: () => Promise<CoreMaintenanceSnapshot>;
    readonly checkUpdates: (request?: {
        readonly sourceId?: string;
        readonly refreshFirst?: boolean;
    }) => Promise<import("../contracts/types.ts").UpdateCheckResult>;
    updatePolicyGet(): Promise<UpdatePolicySnapshot>;
    updatePolicySave(request: UpdatePolicySaveRequest): Promise<UpdatePolicySnapshot>;
    authorDraftList(): readonly AuthorDraft[];
    authorDraftGet(id: string): AuthorDraft;
    authorDraftSave(input: AuthorDraftInput): AuthorDraft;
    authorDraftDelete(request: AuthorDraftDeleteRequest): boolean;
    authorReadmeImport(request: ReadmeImportRequest): Promise<ReadmeImportResult>;
    authorReadmePreview(request: ReadmeImportRequest): Promise<ReadmePreviewView>;
    authorReadmeApplyPreview(request: ReadmeApplyPreviewRequest): ReadmeImportResult;
    authorTransferBegin(request: TransferBeginRequest): TransferResult;
    authorTransferChunk(request: TransferChunkRequest): Promise<TransferResult>;
    authorTransferRead(request: TransferChunkReadRequest): TransferChunkReadResult;
    authorTransferDispose(request: TaskIdRequest): boolean;
    authorExportDraft(request: AuthorExportRequest): TransferResult;
    authorMediaRead(request: AuthorMediaReadRequest): AuthorMediaReadResult;
    private fingerprint;
    private targetState;
    private targetRelease;
    private targetDelivery;
    private riskyImpact;
    aiAnalyze(request: AiAnalyzeRequest, callerId?: string, signal?: AbortSignal): Promise<AiAnalysisResult>;
    aiConfirm(request: AiConfirmRequest, callerId?: string): Promise<AiApplyResult>;
    private executeAiProposal;
    diagnosticsExport(selection?: AiAnalyzeRequest): Promise<DiagnosticExport>;
}
export {};
//# sourceMappingURL=market-runtime.d.ts.map