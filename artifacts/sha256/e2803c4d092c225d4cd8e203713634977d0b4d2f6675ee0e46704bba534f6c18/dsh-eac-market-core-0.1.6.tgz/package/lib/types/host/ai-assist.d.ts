import type { AiAnalysisResult, AiAnalyzeRequest, AiProposal, DiagnosticExport } from '../contracts/types.ts';
interface LlmChunk {
    type: string;
    text?: string;
    reason?: {
        kind?: string;
    };
    blockType?: string;
    block?: {
        type?: string;
    };
}
interface LlmService {
    stream(options: Record<string, unknown>): AsyncIterable<LlmChunk>;
}
interface DefaultModel {
    currentSelection(): {
        provider: string;
        model: string;
        reasoningEffort?: string;
    };
}
type ServiceSource<T> = T | undefined | (() => T | undefined);
export declare function proposalDigest(proposal: AiProposal): string;
export declare class AiAssistant {
    private readonly llm;
    private readonly model;
    constructor(llm: ServiceSource<LlmService>, model: ServiceSource<DefaultModel>);
    private services;
    available(): boolean;
    impactDigest(proposal: AiProposal): string;
    analyze(request: AiAnalyzeRequest, diagnostics: DiagnosticExport, signal?: AbortSignal): Promise<AiAnalysisResult>;
}
export {};
//# sourceMappingURL=ai-assist.d.ts.map