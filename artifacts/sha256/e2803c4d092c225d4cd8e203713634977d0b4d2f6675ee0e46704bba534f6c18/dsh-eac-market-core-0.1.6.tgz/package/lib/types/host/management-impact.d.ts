/**
 * Bounded package-graph inspection for AI remove/downgrade. Reading manifests
 * never loads plugin JavaScript. Missing graph/evidence blocks only this risky
 * suggestion; ordinary browsing and official manual management remain usable.
 */
import type { AiActionImpact, CatalogPlugin, InventorySnapshot } from '../contracts/types.ts';
export interface ManagementManifest {
    readonly name: string;
    readonly version: string;
    readonly dependencies?: Readonly<Record<string, string>>;
    readonly optionalDependencies?: Readonly<Record<string, string>>;
    readonly peerDependencies?: Readonly<Record<string, string>>;
    /** Host-supplied resolver identity, never read from author JSON. */
    readonly resolutionKey?: string | undefined;
}
export type ManagementManifestReader = (name: string, parent?: string) => ManagementManifest | undefined;
export declare function assessRiskyAction(input: {
    readonly kind: 'remove' | 'downgrade';
    readonly packageName: string;
    readonly currentVersion: string;
    readonly target?: CatalogPlugin | undefined;
    readonly current?: CatalogPlugin | undefined;
    readonly inventory: InventorySnapshot;
    readonly readManifest: ManagementManifestReader;
}): AiActionImpact;
//# sourceMappingURL=management-impact.d.ts.map