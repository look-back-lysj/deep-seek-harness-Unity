import type { AiApplyResult, AiProposal, AiRiskChallenge } from '../contracts/types.ts';
import type { ProfileLockPort } from '../core/ports.ts';
import { type PersistenceFilePort } from '../persistence/files.ts';
export interface SavedAiProposal {
    readonly schemaVersion: 1;
    readonly callerId: string;
    readonly proposal: AiProposal;
    readonly inventoryDigest: string;
    readonly deliveryDigest: string;
    readonly stage: 'proposed' | 'challenge' | 'dispatched' | 'settled';
    readonly challenge?: AiRiskChallenge | undefined;
    readonly executionKey?: string | undefined;
    readonly result?: AiApplyResult | undefined;
}
export declare class AiProposalStore {
    private readonly files;
    private readonly locks;
    private readonly environmentId;
    constructor(files: PersistenceFilePort, locks: ProfileLockPort, environmentId: string);
    private path;
    private cancellationPath;
    private isCancelled;
    get(id: string): Promise<SavedAiProposal | undefined>;
    put(record: SavedAiProposal): Promise<void>;
    /** Cancel a late analysis result without deleting its audit record. */
    invalidateAnalysis(id: string): Promise<void>;
    exclusive<T>(id: string, action: () => Promise<T>): Promise<T>;
}
//# sourceMappingURL=ai-proposal-store.d.ts.map