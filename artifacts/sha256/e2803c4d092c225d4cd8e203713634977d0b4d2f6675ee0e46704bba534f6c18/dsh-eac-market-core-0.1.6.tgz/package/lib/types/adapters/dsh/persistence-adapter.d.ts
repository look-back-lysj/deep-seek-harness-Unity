import type { PersistenceFilePort } from '../../persistence/files.ts';
import type { ProfileLockHandle, ProfileLockPort } from '../../core/ports.ts';
export type AtomicWriteCapabilityLoader = () => Promise<unknown>;
export declare class NodePersistenceFiles implements PersistenceFilePort {
    private readonly root;
    private readonly atomic;
    constructor(root: string, loader?: AtomicWriteCapabilityLoader);
    private path;
    read(path: string): Promise<Uint8Array | undefined>;
    writeAtomic(path: string, data: Uint8Array): Promise<void>;
    append(path: string, data: Uint8Array): Promise<void>;
    list(prefix: string): Promise<readonly string[]>;
    remove(path: string): Promise<void>;
    size(path: string): Promise<number | undefined>;
}
export declare class AtomicProfileLocks implements ProfileLockPort {
    private readonly root;
    private readonly waitMs;
    private readonly atomic;
    constructor(root: string, waitMs?: number, loader?: AtomicWriteCapabilityLoader);
    acquire(profileKey: string, owner: string): Promise<ProfileLockHandle>;
}
//# sourceMappingURL=persistence-adapter.d.ts.map