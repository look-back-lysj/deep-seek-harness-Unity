/**
 * Connects verified delivery cache to the core ArtifactPort. `localRef` stays
 * inside Host code and is never included in a Remote result.
 */
import type { CatalogDelivery } from '../../contracts/types.ts';
import type { ArtifactAcquireRequest, ArtifactAcquisition, ArtifactPort } from '../../core/ports.ts';
import { ArtifactCache } from '../../delivery/cache.ts';
export declare class CatalogArtifactPort implements ArtifactPort {
    private readonly cache;
    private readonly allowLocalFileSources;
    constructor(cache: ArtifactCache, _deliveries: () => readonly CatalogDelivery[], allowLocalFileSources?: readonly string[]);
    acquire(request: ArtifactAcquireRequest, signal?: AbortSignal): Promise<ArtifactAcquisition>;
    release(localRef: string): Promise<void>;
}
//# sourceMappingURL=artifact-adapter.d.ts.map