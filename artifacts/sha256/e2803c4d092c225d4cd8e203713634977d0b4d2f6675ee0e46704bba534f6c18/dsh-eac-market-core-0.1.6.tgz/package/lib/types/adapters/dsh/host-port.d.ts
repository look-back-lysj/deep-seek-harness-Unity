import type { Context } from '@deepseek-ai/cordis';
import type { ChangeResult } from '@deepseek-ai/dsh-plugin-manager/types';
import type { HostCancelOutcome, HostInstallOutcome, HostInstallRequest, HostPort, HostReadState } from '../../core/ports.ts';
/** Keeps useful official diagnostics bounded and strips credentials/absolute paths. */
export declare function redactDiagnostic(value: string, limit?: number): string;
export declare function mapOfficialChange(value: unknown, _approvedBuilds?: readonly string[], attemptId?: string): Promise<HostInstallOutcome>;
export declare function officialResultTarget(value: unknown): string | undefined;
export declare class OfficialHostPort implements HostPort {
    private readonly ctx;
    private readonly environmentId;
    private readonly hostIdentity?;
    readonly requiresFrozenDelivery = true;
    private readonly adapter;
    private readonly receipts;
    private readonly active;
    constructor(ctx: Context, environmentId?: string, hostIdentity?: {
        readonly hostVersion: string;
        readonly profileName: string;
    } | undefined);
    /** Resolve at call time: pluginManager may activate after this service. */
    private get manager();
    capabilities(): readonly import('../../contracts/types.ts').CapabilityName[];
    readState(): Promise<HostReadState & {
        readonly hostFingerprint?: string;
    }>;
    private receiptPath;
    private readReceipt;
    private artifactMatches;
    /** Rebuild ownership from receipts, current references and current bytes. */
    private sourceEvidence;
    install(request: HostInstallRequest): Promise<HostInstallOutcome>;
    reconcileInstall(requestId: string): Promise<HostInstallOutcome | undefined>;
    cancel(requestId: string): Promise<HostCancelOutcome>;
    setEnabled(packageName: string, enabled: boolean): Promise<HostInstallOutcome>;
    remove(packageName: string): Promise<ChangeResult | HostInstallOutcome>;
}
//# sourceMappingURL=host-port.d.ts.map