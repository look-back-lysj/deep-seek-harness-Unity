/**
 * Thin official plugin-manager adapter. The market never edits profile YAML or
 * runs its own package manager; all write calls later delegate here.
 */
import type { Context } from '@deepseek-ai/cordis';
import { type IncompatibleBundleEvidence } from './incompatible-evidence.ts';
import type { CapabilityName, InventorySnapshot } from '../../types.ts';
export interface OfficialManager {
    listBundles?(): Promise<unknown[]>;
    listPlugins?(): Promise<unknown[]>;
    setBundleEnabled?(name: string, enabled: boolean): Promise<unknown>;
    setPluginEnabled?(id: string, enabled: boolean): Promise<unknown>;
    installBundle?(spec: string, options?: unknown): Promise<unknown>;
    removeBundle?(name: string): Promise<unknown>;
    inspect?(spec: string, options?: unknown): Promise<unknown>;
    cancelInstall?(requestId: string): Promise<unknown>;
    waitForInstall?(requestId: string): Promise<unknown>;
}
export interface InventorySourceEvidence {
    readonly packageName: string;
    readonly kind: 'market-cache-file' | 'profile' | 'file' | 'link' | 'fork' | 'unknown';
    /** Produced only after durable receipt, dependency reference and bytes agree. */
    readonly receiptId?: string;
    readonly version?: string;
    readonly digest?: string;
    readonly dependencyRef?: string;
    readonly cacheRef?: string;
    readonly restartRequired?: boolean;
}
/** Internal Host evidence only; no new capability or browser-supplied facts. */
export interface DshManagerAdapterOptions {
    readonly hostVersion?: string;
    readonly readIncompatibleEvidence?: (packageName: string) => Promise<IncompatibleBundleEvidence>;
}
/** Read-only capabilities and inventory projection of the official manager. */
export declare class DshManagerAdapter {
    private readonly ctx;
    private readonly environmentId;
    private readonly sourceEvidence;
    private readonly options;
    constructor(ctx: Context, environmentId?: string, sourceEvidence?: readonly InventorySourceEvidence[] | (() => Promise<readonly InventorySourceEvidence[]>), options?: DshManagerAdapterOptions);
    private get manager();
    capabilities(): readonly CapabilityName[];
    /**
     * Never erase unknownItems. Resolve only a corroborated official refusal,
     * sampling both official lists and installed metadata twice. A failed or
     * changed read simply leaves the original version/error unknown in place.
     */
    private rejectedVersions;
    inventory(environmentId?: string): Promise<InventorySnapshot>;
}
//# sourceMappingURL=manager.d.ts.map