import type { Context } from '@deepseek-ai/cordis';
/** Host-private evidence, never a Remote DTO or authority to manage the package. */
export interface IncompatibleBundleEvidence {
    readonly packageName: string;
    readonly version: string;
    readonly dependencyRef: string;
    readonly peers: Readonly<Record<string, string>>;
    readonly fingerprint: string;
    readonly sharedImpact: 'none' | 'unknown';
}
export declare const PACKAGE_NAME: RegExp;
/**
 * Anchors come exclusively from the running Host. The official resolver's
 * installation-first precedence prevents attributing a shadow profile copy to
 * the package rejected by listBundles(). Read only package.json metadata.
 */
export declare function readIncompatibleBundleEvidence(ctx: Context, packageName: string): Promise<IncompatibleBundleEvidence>;
//# sourceMappingURL=incompatible-evidence.d.ts.map