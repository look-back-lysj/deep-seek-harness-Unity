import type { CatalogPlugin, PackComponent } from '../contracts/types.ts';
import { type CatalogHostEvidenceContext, type RawDocumentRecord } from './model.ts';
export declare function validatePackageMetadata(value: unknown, field: string, maxRangeBytes?: number): void;
export declare function validatePublicManifest(bytes: Uint8Array, plugin: Pick<CatalogPlugin, 'id' | 'version' | 'artifactDigest'>): void;
export interface PublicPackLockComponent {
    readonly id: string;
    readonly version: string;
    readonly source: string;
    readonly manifest: string;
    readonly manifestDigest: string;
    readonly artifactDigest: string;
}
export declare function validatePublicPackLock(bytes: Uint8Array, packId: string, packVersion: string, expected: readonly PackComponent[]): readonly PublicPackLockComponent[];
export declare function validatePublicPack(bytes: Uint8Array, packId: string, packVersion: string, components: readonly PackComponent[]): void;
export interface EvidenceSummary {
    readonly level: string;
    readonly result: string;
    readonly revoked: boolean;
    readonly expiresAt?: string;
    readonly hostId?: string;
    readonly hostDshVersion?: string;
    readonly hostRuntime?: string;
    readonly testedAt: string;
    readonly checksPassed: boolean;
}
export declare function validatePublicEvidence(bytes: Uint8Array, plugin: Pick<CatalogPlugin, 'id' | 'version' | 'artifactDigest'>, manifestDigest: string): EvidenceSummary;
export declare function evidenceSupportsVerification(summary: EvidenceSummary, context: CatalogHostEvidenceContext, now: Date): boolean;
export declare function rawDigest(bytes: Uint8Array): string;
export declare function rawRecord(bytes: Uint8Array): RawDocumentRecord;
//# sourceMappingURL=public-format.d.ts.map