/**
 * 受控目录来源配置。
 *
 * 目录地址不是“看到 HTTPS 就可信”：只有维护者显式登记的来源才可刷新。
 * 这里只负责配置、读取和回退，不把任何来源自动升级为正式发布授权。
 */
import { type RemoteSecurityOptions } from '../delivery/security.ts';
export type CatalogSourceTrust = 'team-registered';
export interface CatalogSourceIdentity {
    readonly id: string;
    readonly indexUrl: string;
    readonly maintainer: string;
    readonly trust: CatalogSourceTrust;
    readonly fallbackId?: string;
    /** 镜像共享的逻辑目录身份，由登记入口绑定，不由 UI 自行声明。 */
    readonly catalogId?: string;
    /** Registered GitHub API file endpoint, requesting original raw bytes. */
    readonly format?: 'json' | 'github-raw';
}
export interface CatalogSourceReadResult {
    readonly bytes: Uint8Array;
    readonly source: CatalogSourceIdentity;
    readonly fallbackUsed: boolean;
}
export interface CatalogSourceConnection {
    readonly source: CatalogSourceIdentity;
    readonly read: () => Promise<Uint8Array | string>;
    readonly readResult?: () => Promise<CatalogSourceReadResult>;
}
export interface CatalogSourceRegistryOptions {
    readonly maxBytes?: number;
    readonly security?: RemoteSecurityOptions;
    readonly fetch?: typeof fetch;
}
export declare class CatalogSourceConfigurationError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
/** Gitee raw URLs redirect to its signed content host. Accept only the exact
 * registered owner/repo/ref/path; never trust a different repo or an arbitrary
 * HTTPS redirect. safeFetch still checks DNS and credentials on every hop. */
export declare function isRegisteredCatalogRedirect(registered: string, target: URL): boolean;
export declare class CatalogSourceRegistry {
    private readonly sources;
    private readonly options;
    constructor(sources: readonly CatalogSourceIdentity[], options?: CatalogSourceRegistryOptions);
    list(): readonly CatalogSourceIdentity[];
    resolve(sourceUrl?: string): CatalogSourceIdentity;
    reader(request?: {
        readonly sourceUrl?: string;
    }): () => Promise<Uint8Array | string>;
    connection(request?: {
        readonly sourceUrl?: string;
    }): CatalogSourceConnection;
}
//# sourceMappingURL=source.d.ts.map