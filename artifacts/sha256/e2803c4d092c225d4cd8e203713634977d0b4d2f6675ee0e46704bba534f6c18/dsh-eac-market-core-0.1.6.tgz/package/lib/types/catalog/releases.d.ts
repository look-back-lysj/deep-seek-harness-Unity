/** 私有发行记录；这里只检查材料一致性，不将许可声明当作法律认证或运行证据。 */
import type { ReleaseRecord, ReleaseStatusRecord, MarketCollection } from './model.ts';
export declare function releaseIdFor(record: Pick<ReleaseRecord, 'pluginId' | 'packageName' | 'version' | 'artifactDigest'>): string;
export declare function parseRelease(value: unknown): ReleaseRecord;
export declare function parseReleaseStatus(value: unknown): ReleaseStatusRecord;
export declare function parseCollection(value: unknown, releases: ReadonlyMap<string, ReleaseRecord>): MarketCollection;
//# sourceMappingURL=releases.d.ts.map