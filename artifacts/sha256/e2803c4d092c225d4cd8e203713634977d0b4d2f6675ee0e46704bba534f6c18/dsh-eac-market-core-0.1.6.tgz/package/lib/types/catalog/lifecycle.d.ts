import type { CatalogSnapshot } from '../contracts/types.ts';
import type { CatalogPublication, ReleaseRecord, ReleaseStatusRecord, ValidatedCatalog } from './model.ts';
export interface CatalogAcceptance {
    readonly schemaVersion: '1';
    readonly publication: CatalogPublication;
    readonly revision: string;
    readonly digest: string;
    readonly storedAt: string;
    readonly releases: Readonly<Record<string, {
        readonly digest: string;
        readonly record: ReleaseRecord;
    }>>;
    readonly statuses: Readonly<Record<string, ReleaseStatusRecord>>;
}
export declare function latestAcceptance(cacheDir: string): CatalogAcceptance | undefined;
export declare function prepareAcceptance(validated: ValidatedCatalog, digest: string, previous?: CatalogAcceptance): CatalogAcceptance;
/** The shipped catalog is trusted history too. Preserve the newer publication
 * identity, but merge release/status ledgers even when that publication omitted
 * events from the bundle. Never rewrite a previously committed acceptance. */
export declare function mergeAcceptanceFloor(floor: CatalogAcceptance, known?: CatalogAcceptance): CatalogAcceptance;
export declare function commitAcceptance(cacheDir: string, acceptance: CatalogAcceptance): void;
export declare function applyKnownLifecycle(snapshot: CatalogSnapshot, acceptance?: CatalogAcceptance): CatalogSnapshot;
//# sourceMappingURL=lifecycle.d.ts.map