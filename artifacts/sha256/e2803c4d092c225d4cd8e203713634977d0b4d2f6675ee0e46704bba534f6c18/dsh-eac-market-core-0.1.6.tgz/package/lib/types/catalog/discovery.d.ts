import type { CatalogDiscovery, CatalogPlugin, CatalogSnapshot } from '../contracts/types.ts';
/**
 * 将目录事实投影成发现页需要的四个分区。
 *
 * 这里不自行计算“高分”：只有目录明确提供 source=score 且带评分时才进入高分分区。
 * 海报优先使用插件截图，再使用对应 Presentation 的第一张媒体；两者都没有时
 * poster 保持缺省，客户端按 title+summary 渲染固定尺寸的默认卡片。
 */
export declare function buildCatalogDiscovery(snapshot: Pick<CatalogSnapshot, 'plugins' | 'presentations' | 'recommendations'>): CatalogDiscovery;
/** 仅供生命周期投影使用，保持推荐分区与当前插件集合一致。 */
export declare function filterCatalogDiscovery(discovery: CatalogDiscovery | undefined, plugins: readonly CatalogPlugin[]): CatalogDiscovery | undefined;
//# sourceMappingURL=discovery.d.ts.map