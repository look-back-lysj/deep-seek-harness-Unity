import type { CatalogSnapshot, PackExecution } from '../contracts/types.ts';
import { type CatalogLimitOptions, type ValidatedCatalog } from './model.ts';
/**
 * 校验完整 MarketIndex，并投影成 Client 可见的 CatalogSnapshot。
 * Manifest/Lock 原字节只留在 Host 返回的内部结构，不跨 Remote 暴露。
 */
export declare function validateMarketIndex(input: unknown, options?: CatalogLimitOptions & {
    readonly origin?: CatalogSnapshot['origin'];
}): ValidatedCatalog;
/** 只允许 complete 且关系无环的 PackExecution 被当作完整执行资料。 */
export declare function isCompletePackExecution(execution: PackExecution): boolean;
//# sourceMappingURL=validate.d.ts.map