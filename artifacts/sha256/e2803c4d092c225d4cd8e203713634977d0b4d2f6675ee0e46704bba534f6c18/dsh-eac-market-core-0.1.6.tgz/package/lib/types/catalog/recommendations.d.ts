import type { CatalogPlugin, CatalogRecommendation } from '../contracts/types.ts';
/** 暂存在 B 私有投影类型；主控给 wire 加同名可选字段即可保持跨层范围。 */
export type RecommendationProjection = CatalogRecommendation & {
    readonly version?: string;
};
/** 人工推荐独立于 distribution；只投影仍生效且确实存在的内容。 */
export declare function parseRecommendations(value: unknown, plugins: readonly CatalogPlugin[], now: Date, strict: boolean): readonly RecommendationProjection[];
//# sourceMappingURL=recommendations.d.ts.map