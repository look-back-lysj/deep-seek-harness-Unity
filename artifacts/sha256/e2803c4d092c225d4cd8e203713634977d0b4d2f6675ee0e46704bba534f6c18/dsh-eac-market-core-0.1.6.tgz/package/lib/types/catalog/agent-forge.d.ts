import type { MarketCatalogSource } from '../contracts/types.ts';
import { type MarketIndexDocument } from './model.ts';
import { type OfflinePackContents, type OfflinePackLimits } from './offline-pack.ts';
import { type RemoteSecurityOptions } from '../delivery/security.ts';
export declare class AgentForgeSourceError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export interface AgentForgeSourceOptions extends RemoteSecurityOptions {
    readonly fetch?: typeof fetch;
    readonly localRoots?: readonly string[];
    readonly maxBytes?: number;
    readonly targetAgent?: string;
    readonly offlinePack?: OfflinePackLimits;
}
export interface AgentForgeCatalog {
    readonly source: Record<string, unknown>;
    readonly index: Record<string, unknown>;
    readonly packages: ReadonlyMap<string, Record<string, unknown>>;
    readonly advisories: ReadonlyMap<string, Record<string, unknown>>;
    readonly sourceRevision: string;
    readonly sourceId: string;
    readonly agentId: string | null;
    readonly stale: boolean;
    readonly origin: 'online' | 'local-file' | 'offline-pack';
    readonly offline?: OfflinePackContents;
}
export interface AgentForgeRefreshResult {
    readonly status: 'refreshed' | 'failed';
    readonly current?: AgentForgeCatalog;
    readonly reason?: string;
}
/** Keeps the last valid Agent Forge projection in this process when refresh fails. Runtime owns disk persistence. */
export declare class AgentForgeSourceCache {
    private cached;
    refresh(source: MarketCatalogSource, options?: AgentForgeSourceOptions): Promise<AgentForgeRefreshResult>;
    current(): AgentForgeCatalog | undefined;
}
export declare function readAgentForgeSource(source: MarketCatalogSource, options?: AgentForgeSourceOptions): Promise<AgentForgeCatalog>;
/** Convert Agent Forge metadata into validated browse-only market listings.
 * This intentionally produces no installable plugin or delivery rows.
 */
export interface AgentForgeVerifiedArtifact {
    readonly pluginId: string;
    readonly packageName: string;
    readonly version: string;
    readonly artifactDigest: string;
    readonly size: number;
    readonly packageJson: string;
    readonly files: readonly string[];
}
export interface AgentForgeProjectionOptions {
    readonly revision: string;
    readonly generatedAt: string;
    readonly sourceUrl: string;
    /** Only verified offline bundle artifacts may become installable rows. */
    readonly offlineArtifacts?: readonly AgentForgeVerifiedArtifact[];
}
export declare function projectAgentForgeCatalog(catalog: AgentForgeCatalog, options: AgentForgeProjectionOptions): MarketIndexDocument;
//# sourceMappingURL=agent-forge.d.ts.map