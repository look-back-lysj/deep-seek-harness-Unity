import { type RawDocumentRecord } from './model.ts';
export declare function invalid(code: string, message: string): never;
export declare function object(value: unknown, field: string): Record<string, unknown>;
export declare function string(value: unknown, field: string, max?: number): string;
export declare function array(value: unknown, field: string, max?: number): unknown[];
export declare function integer(value: unknown, field: string, min?: number, max?: number): number;
export declare function boolean(value: unknown, field: string): boolean;
export declare function digest(value: unknown, field: string): string;
export declare function exactVersion(value: unknown, field: string): string;
export declare function timestamp(value: unknown, field: string): string;
export declare function httpsUrl(value: unknown, field: string): string;
export declare function relativeFile(value: unknown, field: string): string;
export declare function hash(bytes: string | Uint8Array): string;
export declare function raw(value: unknown, field: string, maxBytes?: number): {
    record: RawDocumentRecord;
    bytes: Buffer;
};
export declare function json(bytes: Uint8Array, field: string): unknown;
//# sourceMappingURL=input.d.ts.map