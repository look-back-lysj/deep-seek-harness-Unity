import type { ReleaseRecord } from './model.ts';
import { type VerifiedTgz } from '../delivery/tgz.ts';
import type { CatalogLimitOptions } from './model.ts';
export interface BuildRecipe {
    readonly schemaVersion: '1';
    readonly kind: 'TeamBuildRecipe';
    readonly repositoryUrl: string;
    readonly commit: string;
    readonly sourceSubdir: string;
    readonly lockFile: string;
    readonly lockDigest: string;
    readonly authorization: {
        readonly basis: 'license' | 'permission';
        readonly reference: string;
        readonly redistribution: true;
    };
    readonly toolchain: readonly {
        readonly name: string;
        readonly version: string;
    }[];
    readonly target: {
        readonly os: string;
        readonly arch: string;
    };
    readonly steps: readonly {
        readonly executable: string;
        readonly args: readonly string[];
    }[];
    readonly allowedLifecycleScripts: readonly string[];
    readonly output: string;
    readonly limits: {
        readonly timeoutSeconds: number;
        readonly memoryMiB: number;
        readonly diskMiB: number;
    };
    readonly credentials: 'none';
}
export declare function validateBuildRecipe(input: unknown): BuildRecipe;
export interface SubmissionValidation {
    readonly status: 'validated-local-materials';
    readonly release: ReleaseRecord;
    readonly artifact: VerifiedTgz;
    readonly publication: 'not-published';
    readonly runtimeVerification: 'not-tested';
    readonly warnings: readonly string[];
}
export declare function validateAuthorSubmission(input: unknown, root: string, options?: {
    readonly allowTestFixture?: boolean;
}): Promise<SubmissionValidation>;
export declare function validateProductionCatalog(input: unknown, options?: CatalogLimitOptions): import("./model.ts").ValidatedCatalog;
//# sourceMappingURL=submission.d.ts.map