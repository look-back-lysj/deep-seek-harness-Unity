/** 市场团队审核事实，不属于官方 dsh 或 Mojobox Evidence。作者声明须先经团队复核。 */
import type { CatalogManagementEvidence } from '../contracts/types.ts';
export declare function parseManagementEvidence(value: unknown, artifactDigest: string | undefined, now: Date): CatalogManagementEvidence;
//# sourceMappingURL=management-evidence.d.ts.map