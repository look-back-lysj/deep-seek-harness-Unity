import type { CatalogPlugin } from '../contracts/types.ts';
import type { MarketPluginMetadata } from './model.ts';
/** 目录里的 files 只供静态预检；下载后必须再次对真实 tgz 文件表核对。 */
export declare function parseMetadata(value: unknown, plugin: CatalogPlugin): MarketPluginMetadata;
//# sourceMappingURL=metadata.d.ts.map