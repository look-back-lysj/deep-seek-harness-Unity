import type { BundleSelectionGraph, BundleSelectionNode, CancelSelectionResult } from '../contracts/types.ts';
/**
 * 宿主之外的事实由 Core 传入；这些值只用于取消保护，不会改变选择图。
 * 数组使用节点 id、pluginId 或 packageName 均可，解析时会统一到图节点。
 */
export interface CancellationSelectionContext {
    readonly selectedPackageIds?: readonly string[];
    readonly installedPackageIds?: readonly string[];
    readonly explicitPackageIds?: readonly string[];
    readonly parallelSelectedPackageIds?: readonly string[];
    readonly otherBundleSelectedPackageIds?: readonly string[];
    readonly completedPackageIds?: readonly string[];
    readonly unknownPackageIds?: readonly string[];
    readonly officialProtectedPackageIds?: readonly string[];
}
export interface SelectionGraphValidation {
    readonly valid: boolean;
    readonly errors: readonly string[];
}
export interface SelectionGraphIndex {
    readonly nodes: ReadonlyMap<string, BundleSelectionNode>;
    readonly dependents: ReadonlyMap<string, readonly string[]>;
    readonly dependencies: ReadonlyMap<string, readonly string[]>;
}
/** Agent Forge v2 package projection inputs. `id` is the package record ID;
 * bundle members refer to it through `memberId`, not packageName.
 */
export interface AgentForgeBundleMemberInput {
    readonly id: string;
    readonly kind?: 'bundle' | 'plugin';
    readonly packageName?: string;
    readonly version?: string;
}
export interface AgentForgeBundleRecordInput {
    readonly id: string;
    readonly kind?: 'bundle' | 'plugin';
    readonly packageName?: string;
    readonly version?: string;
    readonly members?: readonly (string | AgentForgeBundleMemberInput)[];
    readonly dependencies?: readonly (string | AgentForgeBundleMemberInput)[];
}
export type AgentForgePackageRecord = Readonly<Record<string, unknown>>;
/** Convert real Agent Forge records, resolving every memberId against record id.
 * Duplicate identities or unsupported references remain validation failures.
 */
export declare function agentForgeBundleRecords(records: readonly unknown[]): readonly AgentForgeBundleRecordInput[];
export interface BuildSelectionGraphResult {
    readonly graph: BundleSelectionGraph;
    readonly validation: SelectionGraphValidation;
}
/**
 * 展开 Agent Forge 的 Bundle 成员和嵌套 Bundle。该投影不推导必选项：
 * Bundle 成员与 dependency 节点始终 optional=true、selected=false；依赖只形成边。
 */
export declare function buildBundleSelectionGraph(records: readonly AgentForgeBundleRecordInput[], rootBundleId: string, revision?: string): BuildSelectionGraphResult;
/** Returns a stable graph index and resolves dependency edges from both node.dependencies and graph.edges. */
export declare function indexSelectionGraph(graph: BundleSelectionGraph): SelectionGraphIndex;
/** Checks duplicate ids, missing roots/references, and dependency cycles before freezing a plan. */
export declare function validateSelectionGraph(graph: BundleSelectionGraph): SelectionGraphValidation;
export declare function selectionDependencies(graph: BundleSelectionGraph, id: string): readonly BundleSelectionNode[];
export declare function selectionDependents(graph: BundleSelectionGraph, id: string): readonly BundleSelectionNode[];
/**
 * 计算普通取消或 Force 取消。普通取消遇到任何依赖者只返回 blocked，不产生取消清单；
 * Force 从依赖叶子向根传播保护，只有未完成且没有外部事实保护的节点才会进入 cascadedCancelled。
 */
export declare function cancelSelection(graph: BundleSelectionGraph, targetId: string, options?: {
    readonly force?: boolean;
    readonly context?: CancellationSelectionContext;
}): CancelSelectionResult;
export declare function canCancelSelection(graph: BundleSelectionGraph, targetId: string, context?: CancellationSelectionContext): boolean;
export declare function buildAgentForgeBundleSelectionGraph(records: readonly unknown[], rootBundleId: string, revision?: string): BuildSelectionGraphResult;
//# sourceMappingURL=bundle-selection.d.ts.map