import type { CatalogSourceIdentity } from './source.ts';
/** Public read-only distribution endpoint. No account or token is required.
 * Keep catalogId stable across mirror moves and retain lifecycle history. */
export declare const DEFAULT_CATALOG_SOURCES: readonly CatalogSourceIdentity[];
//# sourceMappingURL=defaults.d.ts.map