import type { OfflinePackArtifact, OfflinePackManifest } from '../contracts/types.ts';
import { type ZipLimits } from '../authoring/zip.ts';
export declare class OfflinePackError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export interface OfflinePackLimits extends ZipLimits {
    readonly maxManifestBytes?: number;
    readonly maxMetadataBytes?: number;
    readonly maxPackages?: number;
    readonly maxArtifactBytes?: number;
}
export interface OfflinePackContents {
    readonly manifest: OfflinePackManifest;
    readonly source: unknown;
    readonly index: unknown;
    readonly packages: ReadonlyMap<string, unknown>;
    readonly advisories: ReadonlyMap<string, unknown>;
    readonly artifacts: ReadonlyMap<string, Uint8Array>;
    readonly artifactEntries: readonly OfflinePackArtifact[];
}
export interface OfflinePackBuildInput {
    readonly manifest: OfflinePackManifest;
    readonly sourceBytes: Uint8Array;
    readonly indexBytes: Uint8Array;
    /** Keys are source-relative package record paths, e.g. `packages/foo.json`. */
    readonly packageRecords: ReadonlyMap<string, Uint8Array>;
    readonly advisories?: ReadonlyMap<string, Uint8Array>;
    /** Keys are the manifest's `sha256:<digest>` values. */
    readonly artifacts: ReadonlyMap<string, Uint8Array>;
}
export declare function readOfflinePack(bytes: Uint8Array, options?: OfflinePackLimits): OfflinePackContents;
export declare function readOfflinePackFile(path: string, options?: OfflinePackLimits): OfflinePackContents;
/**
 * Build a portable `.eacpack` and run the same importer validation before
 * returning it. The caller supplies bytes, while all archive paths are fixed
 * under the controlled manifest layout.
 */
export declare function createOfflinePack(input: OfflinePackBuildInput): Uint8Array;
//# sourceMappingURL=offline-pack.d.ts.map