import type { CatalogSnapshot } from '../contracts/types.ts';
import { MARKET_INDEX_SCHEMA_VERSION, type CatalogLimitOptions, type MarketIndexDocument } from './model.ts';
import type { CatalogSourceConnection, CatalogSourceIdentity } from './source.ts';
import type { MarketCollection } from './model.ts';
import { type CollectionPlanInput, type CatalogCollectionView } from './collections.ts';
export type CatalogSourceReader = () => Promise<Uint8Array | string>;
export interface CatalogLoadResult {
    readonly snapshot: CatalogSnapshot;
    readonly source: 'embedded' | 'cache';
    readonly cacheUsable: boolean;
    readonly reason?: string;
}
export interface CatalogRefreshResult {
    readonly status: 'refreshed' | 'failed';
    readonly current: CatalogLoadResult;
    readonly reason?: string;
    readonly source?: Pick<CatalogSourceIdentity, 'id' | 'indexUrl'>;
}
export interface CatalogRefreshOptions {
    readonly source?: Pick<CatalogSourceIdentity, 'id' | 'indexUrl' | 'catalogId'>;
}
export interface CatalogSourceRefreshInput {
    readonly source: Pick<CatalogSourceIdentity, 'id' | 'indexUrl'>;
    readonly read: () => Promise<Uint8Array | string>;
}
export declare class CatalogRepository {
    private readonly embedded;
    private readonly embeddedDocument;
    private readonly embeddedBytes;
    private readonly hasEmbeddedRaw;
    private readonly cacheDir;
    private readonly limits;
    private cached;
    private cachedValidation;
    private acceptance;
    private pending;
    private projectionDocument;
    private acceptanceFailure;
    constructor(embeddedDocument: unknown, cacheDir: string, limits?: CatalogLimitOptions, embeddedRaw?: Uint8Array);
    /** Shared by browsing, refresh admission and the final install guard. Read
     * disk first: corrupt history must never be treated as an empty cache. */
    private readAcceptance;
    load(): CatalogLoadResult;
    refresh(reader: CatalogSourceReader, options?: CatalogRefreshOptions): Promise<CatalogRefreshResult>;
    private refreshSerial;
    /** 使用维护者登记的来源连接刷新；读取、校验、写盘失败都只回到同一旧快照/Lock。 */
    refreshWithSource(connection: CatalogSourceConnection | CatalogSourceRefreshInput): Promise<CatalogRefreshResult>;
    /** 更新目录只改变浏览快照；安装层必须继续持有旧 planDigest，不能被新目录静默替换。 */
    snapshotForInstall(): CatalogSnapshot;
    /** 私有组合不投影成公共 Pack；主控用同一核心规划器处理 selections 和完整依赖。 */
    collections(): readonly MarketCollection[];
    collection(id: string, version: string): MarketCollection | undefined;
    collectionViews(): readonly CatalogCollectionView[];
    /** 这是市场私有执行输入，documentBytes 不能解释为公共 Lock。
     * selectedPluginIds 可省略为整套；显式子集允许用户去掉可选项，但不能省略必选项。
     * 单项不兼容/缺安装声明继续交核心生成逐项 blocker，不把整个混合组合谎报成功。
     */
    collectionForPlan(id: string, version: string, selectedPluginIds?: readonly string[]): CollectionPlanInput;
    assertReleaseActive(pluginId: string, version: string, artifactDigest: string): void;
    /** Exact Lock bytes for one catalog Pack; callers must not mutate the result. */
    lockBytes(packId: string, packVersion: string): Uint8Array | undefined;
}
export type { MarketIndexDocument };
export { MARKET_INDEX_SCHEMA_VERSION };
//# sourceMappingURL=store.d.ts.map