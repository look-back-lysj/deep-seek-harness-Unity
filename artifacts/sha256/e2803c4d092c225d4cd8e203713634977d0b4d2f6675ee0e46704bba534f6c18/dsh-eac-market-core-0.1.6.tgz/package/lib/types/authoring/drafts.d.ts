import type { AuthorDraft, AuthorDraftInput } from '../contracts/types.ts';
import type { AuthorProvenance } from './package.ts';
export interface DraftStoreOptions {
    readonly maxTextBytes?: number;
    readonly maxDrafts?: number;
    readonly now?: () => Date;
    readonly idFactory?: () => string;
}
export declare class AuthorDraftValidationError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare class AuthorDraftConflictError extends Error {
    readonly expectedRevision: string | undefined;
    readonly actualRevision: string;
    constructor(expectedRevision: string | undefined, actualRevision: string);
}
export declare class AuthorDraftStore {
    private readonly root;
    private readonly maxTextBytes;
    private readonly maxDrafts;
    private readonly now;
    private readonly idFactory;
    constructor(root: string, options?: DraftStoreOptions);
    private draftDir;
    list(): readonly AuthorDraft[];
    get(id: string): AuthorDraft;
    /** provenance 与正文放进同一个原子文件，导入失败不能留下新正文配旧署名。 */
    provenance(id: string): AuthorProvenance | undefined;
    /** 导出参数只改署名材料，不改正文 revision；同一原子文件保留当前正文。 */
    setProvenance(id: string, provenance: AuthorProvenance): void;
    create(input: AuthorDraftInput, provenance?: AuthorProvenance): AuthorDraft;
    update(input: AuthorDraftInput & {
        readonly id: string;
    }, provenance?: AuthorProvenance): AuthorDraft;
    delete(id: string, expectedRevision: string): void;
    mediaDirectory(id: string): string;
    private writeAtomic;
}
//# sourceMappingURL=drafts.d.ts.map