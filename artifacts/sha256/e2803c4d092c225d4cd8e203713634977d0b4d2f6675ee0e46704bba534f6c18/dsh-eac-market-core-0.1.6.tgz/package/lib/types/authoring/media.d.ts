export interface MediaLimits {
    readonly maxFileBytes?: number;
    readonly maxFiles?: number;
    readonly maxTotalBytes?: number;
}
export interface StoredMedia {
    readonly id: string;
    readonly filename: string;
    readonly mediaType: string;
    readonly size: number;
    readonly sha256: string;
}
export declare class MediaValidationError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare class MediaStore {
    private readonly root;
    private readonly maxFileBytes;
    private readonly maxFiles;
    private readonly maxTotalBytes;
    constructor(root: string, limits?: MediaLimits);
    save(bytes: Uint8Array, filename: string): StoredMedia;
    get(id: string): {
        readonly metadata: StoredMedia;
        readonly bytes: Uint8Array;
    };
    list(): readonly StoredMedia[];
}
//# sourceMappingURL=media.d.ts.map