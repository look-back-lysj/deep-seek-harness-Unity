import type { AuthorDraft } from '../contracts/types.ts';
import { AuthorDraftStore, type DraftStoreOptions } from './drafts.ts';
import { MediaStore, type MediaLimits, type StoredMedia } from './media.ts';
import { type ZipLimits } from './zip.ts';
export declare const AUTHOR_EXPORT_FILENAME = "presentation.eac-market-presentation.zip";
export interface AuthorProvenance {
    readonly repositoryUrl?: string;
    readonly commit?: string;
    readonly license?: string;
    readonly licenseNotice?: string;
    readonly notes?: string;
    readonly attribution?: string;
    readonly licenseUrl?: string;
}
export interface AuthorPackageResult {
    readonly draft: AuthorDraft;
    readonly provenance: AuthorProvenance;
    readonly warnings: readonly string[];
}
/** 有界预览；只返回当前草稿引用的图片，无本机路径。 */
export interface AuthorMediaView extends StoredMedia {
    readonly draftId: string;
    readonly data: string;
}
export declare class AuthorPackageError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare class AuthorPackageService {
    readonly drafts: AuthorDraftStore;
    readonly media: MediaStore;
    private readonly zipLimits;
    private readonly provenanceDir;
    constructor(root: string, options?: {
        readonly draft?: DraftStoreOptions;
        readonly media?: MediaLimits;
        readonly zip?: ZipLimits;
    });
    private provenancePath;
    readProvenance(draftId: string): AuthorProvenance;
    private writeProvenance;
    export(draftId: string, provenance?: AuthorProvenance): Uint8Array;
    readMedia(draftId: string, mediaId: string): AuthorMediaView;
    attachMedia(draftId: string, expectedRevision: string, bytes: Uint8Array, filename: string): {
        readonly draft: AuthorDraft;
        readonly media: StoredMedia;
    };
    /**
     * 导入只产生作者草稿/媒体，不会注册 Delivery、执行脚本或触发安装。
     * targetDraftId + expectedRevision 用于更新；缺 expectedRevision 时只能新建，避免并发覆盖。
     */
    import(archive: Uint8Array, options?: {
        readonly targetDraftId?: string;
        readonly expectedRevision?: string;
        readonly defaultProvenance?: AuthorProvenance;
    }): AuthorPackageResult;
}
//# sourceMappingURL=package.d.ts.map