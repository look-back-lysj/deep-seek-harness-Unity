/**
 * Markdown 安全子集。
 *
 * 作者正文是不可信输入。这里只生成固定白名单标签，原始 HTML 一律当文本转义；
 * 链接只允许 https/http/mailto/media，javascript/data/file 等不会成为可点击 URL。
 */
export interface SafeMarkdownResult {
    readonly html: string;
    readonly warnings: readonly string[];
}
export declare class MarkdownSecurityError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare function renderSafeMarkdown(markdown: string, options?: {
    readonly maxBytes?: number;
    readonly resolveMedia?: (id: string) => string | undefined;
}): SafeMarkdownResult;
/** 导入外部 Markdown 后先把相对图片改写为受控 media://，再做预览。 */
export interface RelativeLinkResolvers {
    readonly image: (path: string) => string | undefined;
    readonly link: (path: string) => string | undefined;
}
export declare function rewriteRelativeLinks(markdown: string, resolve: RelativeLinkResolvers, warnings: string[]): string;
export declare function rewriteRelativeImages(markdown: string, resolveRelative: (path: string) => string | undefined, warnings: string[]): string;
//# sourceMappingURL=markdown.d.ts.map