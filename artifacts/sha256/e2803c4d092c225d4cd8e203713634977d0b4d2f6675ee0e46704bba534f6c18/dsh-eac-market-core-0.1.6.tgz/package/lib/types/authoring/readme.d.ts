import type { AuthorDraft, AuthorDraftInput, ReadmeImportRequest, ReadmeImportResult } from '../contracts/types.ts';
import { AuthorDraftStore, AuthorDraftConflictError, type DraftStoreOptions } from './drafts.ts';
import { MediaStore, type MediaLimits } from './media.ts';
import { type RemoteSecurityOptions } from '../delivery/security.ts';
export interface RemoteBytesReader {
    readonly readJson: (url: string) => Promise<unknown>;
    readonly readBytes: (url: string) => Promise<Uint8Array>;
}
export interface ReadmeImporterOptions {
    readonly remote?: RemoteBytesReader;
    readonly security?: RemoteSecurityOptions;
    readonly draft?: DraftStoreOptions;
    readonly media?: MediaLimits;
    readonly maxReadmeBytes?: number;
    readonly maxMediaFiles?: number;
    readonly now?: () => Date;
}
export type ReadmeImportRequestWithRevision = ReadmeImportRequest & {
    readonly expectedRevision?: string | undefined;
};
export interface ReadmePreview {
    readonly previewId: string;
    readonly expiresAt: string;
    readonly before?: AuthorDraft;
    readonly candidate: AuthorDraftInput;
    readonly repositoryUrl: string;
    readonly commit: string;
    readonly importedAt: string;
    readonly mediaWarnings: readonly string[];
}
export declare class ReadmeImportError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare class ReadmeImporter {
    readonly drafts: AuthorDraftStore;
    readonly media: MediaStore;
    private readonly remote;
    private readonly maxReadmeBytes;
    private readonly maxMediaFiles;
    private readonly now;
    private readonly previews;
    private readonly packages;
    constructor(root: string, options?: ReadmeImporterOptions);
    importReadme(request: ReadmeImportRequestWithRevision): Promise<ReadmeImportResult>;
    /** 只生成差异候选；下载图片可留为无引用缓存，不更改目标正文/revision。 */
    previewReadme(request: ReadmeImportRequestWithRevision): Promise<ReadmePreview>;
    /** 用户确认后消费同一份候选字节；不重新请求浮动分支。 */
    applyReadmePreview(request: {
        readonly previewId: string;
        readonly expectedRevision?: string;
    }): ReadmeImportResult;
    private applyPrepared;
    private prepare;
}
export { AuthorDraftConflictError };
//# sourceMappingURL=readme.d.ts.map