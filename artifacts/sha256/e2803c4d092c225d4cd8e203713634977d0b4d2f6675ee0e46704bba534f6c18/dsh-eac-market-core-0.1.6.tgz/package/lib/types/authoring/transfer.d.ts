import type { TransferBeginRequest, TransferChunkRequest, TransferResult } from '../contracts/types.ts';
export interface TransferContext {
    readonly ownerId: string;
    readonly targetId?: string;
}
export interface TransferLimits {
    readonly blockBytes?: number;
    readonly maxBytes?: number;
    readonly maxTransfers?: number;
}
export interface TransferReadResult {
    readonly transferId: string;
    readonly sequence: number;
    readonly data: string;
    readonly last: boolean;
}
export type TransferFinisher = (transfer: {
    readonly transferId: string;
    readonly path: string;
    readonly request: TransferBeginRequest;
}) => Promise<string | undefined>;
export declare class TransferError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare class TransferManager {
    private readonly root;
    private readonly limits;
    private readonly finisher;
    constructor(root: string, options?: TransferLimits & {
        readonly finisher?: TransferFinisher;
    });
    private metaPath;
    private dataPath;
    private read;
    private write;
    begin(request: TransferBeginRequest, context: TransferContext): TransferResult;
    writeChunk(ownerId: string, request: TransferChunkRequest): Promise<TransferResult>;
    stageOutbound(ownerId: string, request: Omit<TransferBeginRequest, 'sha256' | 'size'> & {
        readonly size?: number;
    }, bytes: Uint8Array): TransferResult;
    readChunk(ownerId: string, transferId: string, sequence: number): TransferReadResult;
    dispose(ownerId: string, transferId: string): void;
}
//# sourceMappingURL=transfer.d.ts.map