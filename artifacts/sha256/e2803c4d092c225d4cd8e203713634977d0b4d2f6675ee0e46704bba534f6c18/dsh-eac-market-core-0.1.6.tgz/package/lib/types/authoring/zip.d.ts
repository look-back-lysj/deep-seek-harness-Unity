export interface ZipEntry {
    readonly path: string;
    readonly data: Uint8Array;
}
export interface ZipLimits {
    readonly maxEntries?: number;
    readonly maxCompressedBytes?: number;
    readonly maxExpandedBytes?: number;
    readonly maxEntryBytes?: number;
    readonly maxCompressionRatio?: number;
}
export declare const DEFAULT_ZIP_LIMITS: Required<ZipLimits>;
export declare class ZipSecurityError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare function safeZipPath(input: string): string;
export declare function createZip(input: readonly ZipEntry[], limits?: ZipLimits): Uint8Array;
export declare function readZip(input: Uint8Array, limits?: ZipLimits): readonly ZipEntry[];
//# sourceMappingURL=zip.d.ts.map