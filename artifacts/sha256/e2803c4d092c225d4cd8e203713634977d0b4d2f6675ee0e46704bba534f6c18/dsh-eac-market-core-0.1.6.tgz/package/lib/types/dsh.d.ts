/** DSH 托管的无界面入口。可复用业务能力，但不是独立安装器或安全沙箱。
 * Context、文件与官方服务留在此入口内部；Client 只消费浏览器安全合同。
 */
import type { Context } from '@deepseek-ai/cordis';
import type { MarketBackend } from './api.ts';
import { type RuntimeIdentity, type RuntimeOptions } from './host/market-runtime.ts';
export type { RuntimeIdentity } from './host/market-runtime.ts';
/** DSH adapter 唯一可公开的运行选项；目录原始字节由随包资源提供。 */
export type DshMarketBackendOptions = Omit<RuntimeOptions, 'embeddedCatalog' | 'embeddedCatalogBytes'> & {
    readonly embeddedCatalogBytes: Uint8Array;
};
export declare function createDshMarketBackend(ctx: Context, identity: RuntimeIdentity, dataDirectory: string, options: DshMarketBackendOptions): MarketBackend;
//# sourceMappingURL=dsh.d.ts.map