/** Browser-safe compatibility rules shared by every presentation adapter.
 * A minor version may add operations; it cannot change existing semantics.
 * Unknown/prerelease protocol identifiers are rejected rather than guessed.
 */
export declare const CORE_API_VERSION = "1.0.0";
export declare const CORE_VERSION = "0.1.6";
/** provider must implement every operation the consumer was built against. */
export declare function supportsApiVersion(provider: string, required: string): boolean;
//# sourceMappingURL=compatibility.d.ts.map