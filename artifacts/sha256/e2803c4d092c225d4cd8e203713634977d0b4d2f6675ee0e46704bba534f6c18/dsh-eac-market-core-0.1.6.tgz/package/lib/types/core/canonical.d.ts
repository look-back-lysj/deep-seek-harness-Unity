/**
 * Deterministic JSON serialization and hashing for immutable market plans.
 *
 * Why: the digest must be reproducible in both Host and Client-safe code without
 * depending on Node filesystem or crypto packages. Web Crypto is available in
 * the official runtime and keeps this module portable.
 */
export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | {
    [key: string]: JsonValue;
};
export declare function canonicalJson(value: unknown): string;
export declare function sha256Hex(value: string | Uint8Array): Promise<string>;
/** Shared challenge digest for an exact, sorted package approval list. */
export declare function pendingBuildsDigest(packages: readonly string[]): Promise<string>;
export declare function deepFreeze<T>(value: T): T;
//# sourceMappingURL=canonical.d.ts.map