import type { UpdatePolicy } from '../contracts/types.ts';
/** Product defaults: checks may run automatically, writes never do. */
export declare const DEFAULT_UPDATE_POLICY: UpdatePolicy;
export interface UpdatePolicyInput {
    readonly automaticChecksEnabled?: unknown;
    readonly automaticDownloadsEnabled?: unknown;
    readonly automaticInstallsEnabled?: unknown;
    readonly intervalMinutes?: unknown;
}
export interface AutomaticUpdateInput {
    readonly now?: Date;
    readonly lastCheckedAt?: Date | string;
    readonly force?: boolean;
}
export interface AutomaticUpdateDecision {
    readonly check: boolean;
    readonly download: boolean;
    readonly install: boolean;
    readonly reasons: readonly string[];
}
/** Normalize persisted settings without allowing malformed data to enable writes. */
export declare function normalizeUpdatePolicy(value?: UpdatePolicyInput | null): UpdatePolicy;
export declare function canAutomaticDownload(policy: UpdatePolicy): boolean;
export declare function canAutomaticInstall(policy: UpdatePolicy): boolean;
/**
 * Decide whether a read-only automatic check is due. An explicit force is still
 * a check, but never turns on download or install. Invalid timestamps fail open
 * for the read-only check and remain closed for write actions.
 */
export declare function shouldAutomaticallyCheck(policy: UpdatePolicy, input?: AutomaticUpdateInput): boolean;
export declare function evaluateAutomaticUpdate(policyInput?: UpdatePolicyInput | null, input?: AutomaticUpdateInput): AutomaticUpdateDecision;
export declare const defaultUpdatePolicy: () => UpdatePolicy;
export declare const automaticUpdateDecision: typeof evaluateAutomaticUpdate;
//# sourceMappingURL=update-policy.d.ts.map