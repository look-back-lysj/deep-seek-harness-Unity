import type { ProfileLockPort } from './ports.ts';
import { type PersistenceFilePort } from '../persistence/files.ts';
export interface MaintenanceDependencyEdge {
    readonly prerequisite: string;
    readonly consumer: string;
}
export interface MaintenanceIntentState {
    /** Changes only when persisted user intent or dependency provenance changes. */
    readonly revision: number;
    /** Packages explicitly chosen by the user; dependencies are tracked separately. */
    readonly explicitPackages: readonly string[];
    readonly dependencyEdges: readonly MaintenanceDependencyEdge[];
}
/**
 * Profile-local, checksum-protected storage for user intent. It deliberately
 * does not reconstruct Explicit from successful historical task receipts.
 * Atomic writes and a profile lock prevent partial or lost updates.
 */
export declare class MaintenanceIntentStore {
    private readonly files;
    private readonly locks;
    private readonly owner;
    constructor(files: PersistenceFilePort, locks: ProfileLockPort, owner?: string);
    load(): Promise<MaintenanceIntentState>;
    private mutate;
    replace(next: Omit<MaintenanceIntentState, 'revision'>): Promise<MaintenanceIntentState>;
    recordPlan(explicitPackages: readonly string[], dependencyEdges: readonly MaintenanceDependencyEdge[]): Promise<MaintenanceIntentState>;
    setExplicit(packageName: string, explicit: boolean): Promise<MaintenanceIntentState>;
    clearPackage(packageName: string): Promise<MaintenanceIntentState>;
}
export declare const MAINTENANCE_INTENT_PATH = "maintenance/intent.json";
//# sourceMappingURL=maintenance-intent-store.d.ts.map