/** 浏览器安全的自保护身份；桌面适配包和执行核心均交由官方入口管理。
 * 冻结数组而非可变 Set，避免使用方误改全局保护范围。
 */
export declare const PROTECTED_MARKET_PACKAGES: readonly string[];
export declare function isProtectedMarketPackage(packageName: string): boolean;
//# sourceMappingURL=identity.d.ts.map