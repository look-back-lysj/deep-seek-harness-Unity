/**
 * Profile-serial install task runner.
 *
 * The manager persists intent before any write, rechecks state immediately
 * before every Host write, and never maps an absent/unknown Host result to
 * success. Synthetic ports are valid test inputs but never become proof of an
 * official install.
 */
import type { TaskApprovalRequest, TaskCancelRequest, TaskResumeRequest, TaskStartRequest, TaskState } from '../contracts/types.ts';
import type { ArtifactPort, EventLogPage, HostInstallOutcome, HostReadState, PlanBundle, ProfileLockPort, TaskEventLogPort, TaskStorePort } from './ports.ts';
import { type RecoverableHostPort, type CoordinatedManagementRequest } from './execution-state.ts';
import { type PersistenceFilePort } from '../persistence/files.ts';
export type { CoordinatedManagementRequest } from './execution-state.ts';
export interface TaskManagerDeps {
    readonly host: RecoverableHostPort;
    readonly coordinationFiles?: PersistenceFilePort;
    /** Host revalidates release withdrawal/hard incompatibility by frozen identity,
     * independent of presentation revisions. Rejecting never authorizes a write. */
    readonly validateWrite?: (bundle: PlanBundle, pluginId: string) => Promise<void>;
    readonly artifacts: ArtifactPort;
    readonly store: TaskStorePort;
    readonly locks: ProfileLockPort;
    readonly events?: TaskEventLogPort;
    readonly owner?: string;
    readonly now?: () => Date;
    readonly maxEventHistory?: number;
}
export interface TaskStartOutcome {
    readonly task: TaskState;
    readonly created: boolean;
}
export declare class InstallTaskManager {
    private readonly deps;
    private readonly queues;
    private readonly downloads;
    private readonly owner;
    private readonly now;
    private readonly maxEventHistory;
    constructor(deps: TaskManagerDeps);
    /** Reconcile receipts under the same execution occupation as every new writer.
     * Disk version alone never proves which interrupted request produced it.
     */
    reconcileInterrupted(environmentId: string): Promise<number>;
    private queue;
    private withLock;
    private withLockFromTask;
    private appendEvent;
    private save;
    private flushEvents;
    start(bundle: PlanBundle, request: TaskStartRequest, baseline: HostReadState): Promise<TaskStartOutcome>;
    private intentDigest;
    private managementRecords;
    private assertNoUncertainWriter;
    private managementVerified;
    /** A saved real receipt can be rechecked after an inventory outage. A missing
     * or unknown receipt never grants permission to run the management callback again. */
    private reconcileManagement;
    /** Host supplies the single confirmed official action. Every caller shares the
     * same execution lock and persistent unknown-write barrier with install tasks.
     * Risk/impact confirmation is the Host's responsibility; this method still
     * verifies object protection, expectedVersion, idempotency and post-write facts.
     */
    manage(request: CoordinatedManagementRequest, write: () => Promise<HostInstallOutcome>): Promise<HostInstallOutcome>;
    /** Native-like installation gate: unrelated inventory uncertainty must not
     * prevent a target install. Real active writers and official run records still
     * block; target identity/drift checks remain in findDrift and applyOutcome. */
    private installStateSettled;
    private inventoryIssueAffectsPackage;
    /** Explicit execution state proves that no official install request was dispatched. */
    private provenNoWrite;
    private cancelUnstarted;
    get(taskId: string): Promise<TaskState | undefined>;
    events(taskId: string, afterSequence?: number, limit?: number): Promise<EventLogPage>;
    cancel(request: TaskCancelRequest): Promise<TaskState>;
    approveBuilds(request: TaskApprovalRequest): Promise<TaskState>;
    prepareResume(taskId: string): Promise<TaskState>;
    private prepareResumeLocked;
    resume(request: TaskResumeRequest): Promise<TaskState>;
    /** Runs one queued task. Callers already enqueue on the environment's serial queue. */
    runTaskLockedId(taskId: string): Promise<void>;
    private pause;
    private runTaskLocked;
    private cancelPending;
    private applyKeepItems;
    private applyOutcome;
    private withoutApproval;
    private withoutResume;
    private clearActiveRequest;
    private updateItem;
    private refreshFacts;
    private factFromInventory;
    private edgeSatisfied;
    private dependencyBlock;
    private findDrift;
    private finalize;
}
/** Small in-memory queue used by Host assembly for one process. */
export declare class ProfileSerialQueues {
    private readonly queues;
    enqueue<T>(profileKey: string, operation: () => Promise<T>): Promise<T>;
}
//# sourceMappingURL=task-manager.d.ts.map