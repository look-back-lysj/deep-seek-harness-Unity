import type { MaintenancePackageState } from '../contracts/types.ts';
export type ExplicitSyncState = MaintenancePackageState['explicitState'];
export type DependencySyncState = MaintenancePackageState['dependencyState'];
/** A dependency edge points from a prerequisite to the package consuming it. */
export interface PackageDependencyEdge {
    readonly prerequisite: string;
    readonly consumer: string;
}
export interface ExplicitSyncInput {
    readonly packageNames: readonly string[];
    readonly explicitPackages?: readonly string[];
    readonly unknownPackages?: readonly string[];
}
export interface DependencySyncInput {
    readonly packageNames?: readonly string[];
    readonly edges: readonly PackageDependencyEdge[];
    /** Selected or installed consumers keep a dependency live. */
    readonly selectedPackages?: readonly string[];
    readonly installedPackages?: readonly string[];
    readonly unknownPackages?: readonly string[];
}
export interface PackageSyncInput extends ExplicitSyncInput {
    readonly edges?: readonly PackageDependencyEdge[];
    readonly selectedPackages?: readonly string[];
    readonly installedPackages?: readonly string[];
}
/** Compute explicit intent without inferring user intent from adapter inventory. */
export declare function computeExplicitSync(input: ExplicitSyncInput): Readonly<Record<string, ExplicitSyncState>>;
/**
 * Compute live dependency consumers. Edges from packages which are neither
 * selected nor installed are intentionally ignored: they describe metadata,
 * not a current cancellation protection.
 */
export declare function computeDependencySync(input: DependencySyncInput): Readonly<Record<string, DependencySyncState>>;
export interface PackageSyncState {
    readonly explicitState: ExplicitSyncState;
    readonly dependencyState: DependencySyncState;
}
/** Merge the two Core-owned facts in one deterministic package-indexed map. */
export declare function computePackageSync(input: PackageSyncInput): Readonly<Record<string, PackageSyncState>>;
export declare function isDependencyProtected(state: DependencySyncState): boolean;
export declare const syncExplicit: typeof computeExplicitSync;
export declare const syncDependency: typeof computeDependencySync;
//# sourceMappingURL=sync-state.d.ts.map