import type { CatalogPlugin, InventorySnapshot, UpdateCheckResult, UpdatePolicy } from '../contracts/types.ts';
import { evaluateAutomaticUpdate, type UpdatePolicyInput } from './update-policy.ts';
export type UpdateCheckStatus = 'update-available' | 'up-to-date' | 'not-in-catalog' | 'unknown' | 'incompatible';
export type { UpdateCheckItem, UpdateCheckResult } from '../contracts/types.ts';
export interface UpdateCheckOptions {
    readonly now?: Date;
    readonly policy?: UpdatePolicyInput | UpdatePolicy | null;
}
/**
 * Compare the verified inventory with a catalog snapshot. This function is
 * deliberately read-only: an update result never authorizes download or
 * installation, and unknown inventory remains unknown instead of becoming a
 * silent update candidate.
 */
export declare function compareInstalledUpdates(inventory: InventorySnapshot, plugins: readonly CatalogPlugin[], sourceRevision: string, options?: UpdateCheckOptions & {
    readonly catalogStale?: boolean;
}): UpdateCheckResult;
/** Decide whether a scheduled check may run; it never grants write access. */
export declare function automaticUpdateCheckDecision(policy: UpdatePolicyInput | UpdatePolicy | null | undefined, input?: Parameters<typeof evaluateAutomaticUpdate>[1]): import("./update-policy.ts").AutomaticUpdateDecision;
//# sourceMappingURL=update-check.d.ts.map