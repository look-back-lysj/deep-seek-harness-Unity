import type { CoreMaintenanceSnapshot, InventorySnapshot, TaskState, UpdatePolicy } from '../contracts/types.ts';
import { type PackageDependencyEdge } from './sync-state.ts';
import { type UpdatePolicyInput } from './update-policy.ts';
export type MaintenanceAction = 'install' | 'update' | 'remove' | 'retain' | 'enable' | 'disable' | 'blocked';
export type MaintenanceOperationPhase = 'pending' | 'in-progress' | 'succeeded' | 'failed' | 'awaiting-restart' | 'unknown';
export interface MaintenanceTarget {
    readonly packageName: string;
    readonly pluginId?: string;
    readonly targetVersion?: string;
    readonly enabled?: boolean;
    readonly action?: MaintenanceAction;
    readonly reason?: string;
}
export interface MaintenanceOperation {
    readonly packageName: string;
    readonly action: MaintenanceAction;
    readonly phase: MaintenanceOperationPhase;
    readonly targetVersion?: string;
    readonly reason?: string;
    readonly restartRequired?: boolean;
}
export interface MaintenanceSnapshotInput {
    readonly environmentId: string;
    readonly inventory: InventorySnapshot;
    readonly revision?: string;
    readonly generatedAt?: Date | string;
    readonly updatePolicy?: UpdatePolicyInput | UpdatePolicy | null;
    readonly tasks?: readonly TaskState[];
    readonly activeTaskIds?: readonly string[];
    readonly targets?: readonly MaintenanceTarget[];
    readonly operations?: readonly MaintenanceOperation[];
    readonly explicitPackages?: readonly string[];
    readonly selectedPackages?: readonly string[];
    readonly dependencyEdges?: readonly PackageDependencyEdge[];
    readonly unknownPackages?: readonly string[];
}
/** Build an Adapter-consumable snapshot from Core-owned facts only. */
export declare function buildMaintenanceSnapshot(input: MaintenanceSnapshotInput): CoreMaintenanceSnapshot;
export declare const createMaintenanceSnapshot: typeof buildMaintenanceSnapshot;
export declare const computeMaintenanceSnapshot: typeof buildMaintenanceSnapshot;
//# sourceMappingURL=maintenance-state.d.ts.map