import type { UpdateCheckResult, UpdatePolicySnapshot } from '../contracts/types.ts';
import type { ProfileLockPort } from './ports.ts';
import { type PersistenceFilePort } from '../persistence/files.ts';
type UpdateCheckRequest = {
    readonly sourceId?: string;
    readonly refreshFirst?: boolean;
};
/** Core-private state. It is persisted for restart recovery but is not a wire DTO. */
export interface UpdateCheckScheduleState {
    readonly lastCheckedAt?: string;
    readonly nextCheckAt?: string;
    readonly lastResult?: UpdateCheckResult;
    readonly lastError?: 'automatic-check-failed';
}
export declare class UpdateCheckScheduleStore {
    private readonly files;
    private readonly locks;
    constructor(files: PersistenceFilePort, locks: ProfileLockPort);
    load(): Promise<UpdateCheckScheduleState>;
    save(state: UpdateCheckScheduleState): Promise<void>;
}
export interface UpdateCheckSchedulerOptions {
    readonly files: PersistenceFilePort;
    readonly locks: ProfileLockPort;
    readonly getPolicy: () => Promise<UpdatePolicySnapshot>;
    readonly checkUpdates: (request?: UpdateCheckRequest) => Promise<UpdateCheckResult>;
    readonly now?: () => Date;
    readonly onError?: (error: unknown) => void;
}
/**
 * Host-lifecycle-owned, read-only update checker. It never creates a plan,
 * downloads an artifact, or starts an install; those remain explicit actions.
 */
export declare class UpdateCheckScheduler {
    private readonly options;
    private readonly store;
    private readonly now;
    private readonly onError;
    private timer;
    private started;
    private running;
    private persistenceBlocked;
    private lifecycle;
    private scheduleGeneration;
    private checkIntervalMs;
    private state;
    constructor(options: UpdateCheckSchedulerOptions);
    start(): Promise<void>;
    stop(): void;
    refresh(): Promise<void>;
    /** Test/diagnostic access to the in-memory view; never exposed through Remote. */
    stateSnapshot(): UpdateCheckScheduleState;
    private clearTimer;
    private report;
    private isActive;
    private persist;
    private recordFailure;
    private intervalMs;
    private dueAt;
    private reschedule;
    private runScheduledCheck;
}
export declare const UPDATE_CHECK_SCHEDULE_PATH = "settings/update-check-state.json";
export {};
//# sourceMappingURL=update-check-scheduler.d.ts.map