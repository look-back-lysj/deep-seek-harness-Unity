export declare function validVersion(value: string): boolean;
export declare function compareVersions(left: string, right: string): number;
//# sourceMappingURL=semver.d.ts.map