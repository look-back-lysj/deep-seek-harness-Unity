import type { PackExecutionContext, CollectionExecutionContext, PlanCatalogContext, PlanBundle, PreparedPlanResult } from './ports.ts';
export { compareVersions } from './semver.ts';
/**
 * Builds and seals a plan. `pack` is optional for single-plugin plans; when
 * present, its Lock bytes are hashed and compared with the private execution
 * record before any dependency is trusted.
 */
export declare function createPlanBundle(context: PlanCatalogContext, pack?: PackExecutionContext | CollectionExecutionContext): Promise<PreparedPlanResult>;
export declare function verifyPlanBundle(bundle: PlanBundle): Promise<boolean>;
//# sourceMappingURL=planner.d.ts.map