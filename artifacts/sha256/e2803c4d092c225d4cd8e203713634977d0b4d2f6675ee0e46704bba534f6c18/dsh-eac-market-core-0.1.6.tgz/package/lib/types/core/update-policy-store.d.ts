import type { UpdatePolicySaveRequest, UpdatePolicySnapshot } from '../contracts/types.ts';
import type { ProfileLockPort } from './ports.ts';
import { type PersistenceFilePort } from '../persistence/files.ts';
export declare class UpdatePolicyStoreError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare class UpdatePolicyStore {
    private readonly files;
    private readonly locks;
    constructor(files: PersistenceFilePort, locks: ProfileLockPort);
    private readSnapshot;
    get(): Promise<UpdatePolicySnapshot>;
    save(request: UpdatePolicySaveRequest): Promise<UpdatePolicySnapshot>;
}
//# sourceMappingURL=update-policy-store.d.ts.map