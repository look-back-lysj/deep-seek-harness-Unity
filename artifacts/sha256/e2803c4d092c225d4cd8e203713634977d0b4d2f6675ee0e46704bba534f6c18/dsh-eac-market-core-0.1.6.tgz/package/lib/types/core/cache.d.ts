/**
 * Cache reference accounting. A cached tgz is deletable only when no active
 * task and no installed market-managed dependency still references it.
 */
export interface CacheReference {
    readonly digest: string;
    readonly localRef: string;
    readonly taskId?: string;
    readonly packageName?: string;
    readonly installed: boolean;
}
export interface CacheCleanupDecision {
    readonly deletableLocalRefs: readonly string[];
    readonly protectedLocalRefs: readonly string[];
}
export declare class CacheReferenceIndex {
    private readonly references;
    constructor(initial?: readonly CacheReference[]);
    retain(reference: CacheReference): void;
    markInstalled(localRef: string, packageName: string): void;
    releaseTask(taskId: string): void;
    snapshot(): readonly CacheReference[];
    collect(activeTaskIds: readonly string[]): CacheCleanupDecision;
}
//# sourceMappingURL=cache.d.ts.map