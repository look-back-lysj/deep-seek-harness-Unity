/** Stable errors for core boundaries; callers must not interpret thrown values as success. */
export declare class MarketCoreError extends Error {
    readonly code: string;
    readonly retryable: boolean;
    readonly nextAction: string;
    readonly details: readonly string[];
    constructor(code: string, message: string, options?: {
        retryable?: boolean;
        nextAction?: string;
        details?: readonly string[];
        cause?: unknown;
    });
}
//# sourceMappingURL=errors.d.ts.map