export interface PersistenceFilePort {
    read(path: string): Promise<Uint8Array | undefined>;
    writeAtomic(path: string, data: Uint8Array): Promise<void>;
    append(path: string, data: Uint8Array): Promise<void>;
    list(prefix: string): Promise<readonly string[]>;
    remove(path: string): Promise<void>;
    size(path: string): Promise<number | undefined>;
}
export declare class PersistenceError extends Error {
    readonly code: string;
    readonly preserveOldData: boolean;
    constructor(code: string, message: string, preserveOldData?: boolean, options?: {
        cause?: unknown;
    });
}
export declare function safeStoreId(value: string): string;
export declare function taskDirectory(taskId: string): string;
export declare function encodeJson(value: unknown): Uint8Array;
export declare function decodeJson(data: Uint8Array): unknown;
/** Reads a versioned document without silently replacing corrupt data. */
export declare function readJsonDocument<T>(files: PersistenceFilePort, path: string, parse: (raw: unknown) => T): Promise<T | undefined>;
/** Uses the adapter's atomic replace; callers must not report success before this resolves. */
export declare function writeJsonDocument(files: PersistenceFilePort, path: string, value: unknown): Promise<void>;
//# sourceMappingURL=files.d.ts.map