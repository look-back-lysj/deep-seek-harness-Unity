/**
 * Persistent TaskStorePort backed by atomic JSON summaries plus a unique
 * environmentId/planId index. The index prevents two tabs or idempotency keys
 * from creating two tasks for one immutable plan.
 */
import type { TaskRecord, TaskStorePort } from '../core/ports.ts';
import { type PersistenceFilePort } from './files.ts';
import type { ProfileLockPort } from '../core/ports.ts';
export declare class JsonTaskStore implements TaskStorePort {
    private readonly files;
    private readonly locks;
    private readonly owner;
    constructor(files: PersistenceFilePort, locks: ProfileLockPort, owner?: string);
    private withStoreLock;
    /** Index is a projection: enumerate summaries/journals even after a failed index write. */
    private readIndex;
    private readDocument;
    get(taskId: string): Promise<TaskRecord | undefined>;
    getByPlan(environmentId: string, planId: string): Promise<TaskRecord | undefined>;
    put(record: TaskRecord): Promise<void>;
    list(environmentId: string): Promise<readonly TaskRecord[]>;
    /** Recovery helper: reads one summary while preserving a corrupt file for inspection. */
    inspectRaw(taskId: string): Promise<unknown>;
}
//# sourceMappingURL=task-store.d.ts.map