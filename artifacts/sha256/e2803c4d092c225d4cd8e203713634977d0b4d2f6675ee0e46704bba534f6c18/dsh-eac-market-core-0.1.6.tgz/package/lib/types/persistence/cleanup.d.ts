/**
 * Bounded task-log cleanup. Summary files are never deleted; only old event
 * segments may be removed and the truncation fact is persisted.
 */
import type { TaskEventLogPort, TaskStorePort } from '../core/ports.ts';
export interface TaskLogCleanupPolicy {
    readonly maxBytesPerTask: number;
    readonly retainSummaries: true;
}
export interface TaskLogCleanupResult {
    readonly taskId: string;
    readonly removedSegments: number;
    readonly truncated: boolean;
    readonly summaryRetained: boolean;
}
export declare function cleanupTaskLogs(store: TaskStorePort, events: TaskEventLogPort, taskIds: readonly string[], policy: TaskLogCleanupPolicy): Promise<readonly TaskLogCleanupResult[]>;
//# sourceMappingURL=cleanup.d.ts.map