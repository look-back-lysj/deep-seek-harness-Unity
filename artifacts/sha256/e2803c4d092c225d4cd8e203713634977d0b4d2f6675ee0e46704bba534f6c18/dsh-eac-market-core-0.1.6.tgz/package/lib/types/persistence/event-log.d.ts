/**
 * Segmented, paginated task event log.
 *
 * Summary JSON remains authoritative for current status. Event segments are
 * append-only, bounded and independently readable; a torn final JSONL line is
 * ignored with `truncated=true`, while corruption in the middle fails closed.
 */
import type { TaskEvent } from '../contracts/types.ts';
import type { TaskEventLogPort, EventLogPage } from '../core/ports.ts';
import { type PersistenceFilePort } from './files.ts';
export declare class SegmentedEventLog implements TaskEventLogPort {
    private readonly files;
    private readonly maxSegmentBytes;
    constructor(files: PersistenceFilePort, maxSegmentBytes?: number);
    private paths;
    private segments;
    append(taskId: string, event: TaskEvent): Promise<void>;
    read(taskId: string, afterSequence: number, limit: number): Promise<EventLogPage>;
    cleanup(taskId: string, maxBytes: number): Promise<{
        removedSegments: number;
        truncated: boolean;
    }>;
}
//# sourceMappingURL=event-log.d.ts.map