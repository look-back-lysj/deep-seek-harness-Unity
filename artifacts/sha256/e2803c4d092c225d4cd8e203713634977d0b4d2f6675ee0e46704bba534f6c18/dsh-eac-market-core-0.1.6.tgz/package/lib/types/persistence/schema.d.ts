/**
 * Versioned task summary schema and migration.
 *
 * Migration failure preserves the old bytes and makes writes fail closed. A
 * missing/corrupt summary is never treated as an empty successful store.
 */
import type { TaskRecord } from '../core/ports.ts';
export declare const TASK_SCHEMA_VERSION = 3;
export interface TaskDocumentV3 {
    readonly schemaVersion: 3;
    readonly record: TaskRecord;
}
/**
 * Accepts known v1/v2 records without inventing dispatch evidence. Unknown
 * future versions fail closed so a downgrade cannot erase new data.
 */
export declare function migrateTaskDocument(raw: unknown): TaskDocumentV3;
//# sourceMappingURL=schema.d.ts.map